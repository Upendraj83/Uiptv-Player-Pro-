# Tiwee Web

**Tiwee** is a modern, high-performance IPTV player web application ported from the original Flutter app. With Tiwee, you can stream live TV channels from all around the world, filtering them by country or category with instant responsiveness.

## Features

- **Global Live Access**: Stream thousands of live TV channels across the globe using HLS and native video playback.
- **Smart Stream Failover**: Automatic fallback to alternate channel sources if a provider is temporarily offline (`_playNextSource`).
- **Category Browsing**: Rich curated category tiles with live channel counts (Movies, Series, Animation, Sports, News, Music, Kids, Cooking, Education, etc.).
- **Country Filter**: Browse live television organized by country with flags, ISO codes, and channels per nation.
- **Saved Channels & Favorites**: Star any channel to save it to your bookmarks with local persistence.
- **Themes**: Switch between **Dark Purple** (`#1c1829`) and **AMOLED True Black** (`#000000`).
- **Parental Controls**: 4-digit PIN protection to lock or reveal adult / NSFW channels.
- **Sleep Timer**: Built-in sleep timer (15, 30, 45, 60, 90, 120 minutes) that automatically ends playback when expired.
- **Digital Clock & Search**: Live digital time header and instant real-time channel search.
- **API Integration**: Powered by the [IPTV-org API](https://github.com/iptv-org/api).

## Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS
- **Streaming Engine**: `hls.js` with HTML5 video fallback
- **Data & Caching**: IndexedDB client cache + IPTV-org JSON API endpoints

## Original Project

- Original Mobile App: [neffex97/tiwee](https://github.com/neffex97/tiwee)
- Design inspired by: [Mohammad Reza Farahzad](https://dribbble.com/shots/14754204-IPTVify-App-Ui-Design)
- Telegram: [@Neffex97](https://telegram.me/Neffex97)
