#!/usr/bin/env python3
"""
Stand-alone Android 10 APK Builder for Tiwee IPTV.
Packages a valid signed Android application package (.apk)
Target SDK: 29 (Android 10)
Min SDK: 21 (Android 5.0+)
Package: com.tiwee.iptv
Version: 2.1.0 (code 20100)
"""

import os
import sys
import struct
import zipfile
import hashlib
import time

def build_utf16_string_pool(strings):
    """Encodes a list of unicode strings into Android RES_STRING_POOL binary format."""
    str_count = len(strings)
    offsets = []
    str_bytes = bytearray()
    
    for s in strings:
        offsets.append(len(str_bytes))
        # UTF-16 string in AXML string pool has:
        # length in chars (2 bytes, or 4 if >= 0x8000), then UTF-16LE characters, then 2 null bytes (0x0000)
        s_utf16 = s.encode('utf-16le')
        char_len = len(s)
        if char_len < 0x8000:
            str_bytes.extend(struct.pack('<H', char_len))
        else:
            # 2 uint16s
            str_bytes.extend(struct.pack('<HH', ((char_len >> 16) & 0x7fff) | 0x8000, char_len & 0xffff))
        str_bytes.extend(s_utf16)
        str_bytes.extend(b'\x00\x00') # null terminator

    # Align string bytes to 4-byte boundary
    pad_len = (4 - (len(str_bytes) % 4)) % 4
    str_bytes.extend(b'\x00' * pad_len)

    header_size = 28 # 0x1C
    offsets_size = str_count * 4
    strings_start = header_size + offsets_size
    chunk_size = strings_start + len(str_bytes)

    # Chunk header: type 0x0001, header_size 0x001c, chunk_size
    pool = bytearray()
    pool.extend(struct.pack('<HHI', 0x0001, 0x001C, chunk_size))
    # stringCount, styleCount, flags (0 = UTF-16), stringsStart, stylesStart
    pool.extend(struct.pack('<IIIII', str_count, 0, 0, strings_start, 0))
    # Offsets
    for off in offsets:
        pool.extend(struct.pack('<I', off))
    # Strings
    pool.extend(str_bytes)
    return pool

def generate_binary_axml():
    """
    Constructs a valid Android binary XML (AXML) for AndroidManifest.xml:
    <manifest xmlns:android="http://schemas.android.com/apk/res/android"
              package="com.tiwee.iptv"
              android:versionCode="20100"
              android:versionName="2.1.0">
        <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="29"/>
        <uses-permission android:name="android.permission.INTERNET"/>
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
        <uses-permission android:name="android.permission.WAKE_LOCK"/>
        <application android:label="Tiwee IPTV"
                     android:icon="@drawable/ic_launcher"
                     android:hardwareAccelerated="true"
                     android:usesCleartextTraffic="true">
            <activity android:name="com.tiwee.iptv.MainActivity"
                      android:label="Tiwee IPTV"
                      android:screenOrientation="unspecified"
                      android:configChanges="orientation|screenSize|keyboardHidden">
                <intent-filter>
                    <action android:name="android.intent.action.MAIN"/>
                    <category android:name="android.intent.category.LAUNCHER"/>
                </intent-filter>
            </activity>
        </application>
    </manifest>
    """
    strings = [
        "http://schemas.android.com/apk/res/android",
        "android",
        "manifest",
        "package",
        "versionCode",
        "versionName",
        "uses-sdk",
        "minSdkVersion",
        "targetSdkVersion",
        "uses-permission",
        "name",
        "application",
        "label",
        "icon",
        "hardwareAccelerated",
        "usesCleartextTraffic",
        "activity",
        "screenOrientation",
        "configChanges",
        "intent-filter",
        "action",
        "category",
        "com.tiwee.iptv",
        "2.1.0",
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.WAKE_LOCK",
        "Tiwee IPTV",
        "@drawable/ic_launcher",
        "com.tiwee.iptv.MainActivity",
        "android.intent.action.MAIN",
        "android.intent.category.LAUNCHER"
    ]
    str_map = {s: i for i, s in enumerate(strings)}

    def idx(s):
        return str_map[s]

    res_ids = [
        0x01010001, # label
        0x01010002, # icon
        0x01010003, # minSdk
        0x01010020, # name
        0x01010028, # screenOrientation
        0x01010029, # configChanges
        0x0101021b, # versionCode
        0x0101021c, # versionName
        0x01010270, # targetSdk
        0x010102d3, # hardwareAccelerated
        0x010104ec, # usesCleartextTraffic
    ]

    # String Pool
    str_pool = build_utf16_string_pool(strings)

    # Resource Map chunk (0x0180)
    res_map_header = struct.pack('<HHI', 0x0180, 0x0008, 8 + len(res_ids) * 4)
    res_map_data = bytearray(res_map_header)
    for rid in res_ids:
        res_map_data.extend(struct.pack('<I', rid))

    chunks = bytearray()
    line_num = 1

    # Start Namespace chunk (0x0100)
    # header: type 0x0100, header_size 0x10, chunk_size 0x18
    # line_number, comment_index (0xffffffff), prefix_index, uri_index
    chunks.extend(struct.pack('<HHIIIII', 0x0100, 0x0010, 0x0018, line_num, 0xFFFFFFFF, idx("android"), idx("http://schemas.android.com/apk/res/android")))

    def make_attr(ns_idx, name_idx, raw_val_idx, type_val, data_val):
        # 20 bytes per attribute
        return struct.pack('<IIIIHBB I', ns_idx, name_idx, raw_val_idx, 0x00080000, 0x08, 0, type_val, data_val)

    def make_start_tag(name_idx, attrs_len, attr_count):
        # type 0x0102, headerSize 0x10, size 0x24 + attrs_len, line_num, comment -1, ns -1, name_idx,
        # attrStart 0x14, attrSize 20, attrCount, id 0, class 0, style 0 (13 items)
        return bytearray(struct.pack('<HHIIIIIHHHHHH', 0x0102, 0x0010, 0x24 + attrs_len, line_num, 0xFFFFFFFF, 0xFFFFFFFF, name_idx, 0x0014, 20, attr_count, 0, 0, 0))

    def make_end_tag(name_idx):
        # type 0x0103, headerSize 0x10, size 0x18, line_num, comment -1, ns -1, name_idx (7 items)
        return struct.pack('<HHIIIII', 0x0103, 0x0010, 0x0018, line_num, 0xFFFFFFFF, 0xFFFFFFFF, name_idx)

    # 1. Start <manifest>
    # attributes: package="com.tiwee.iptv", versionCode=20100, versionName="2.1.0"
    attrs = bytearray()
    # package (no namespace)
    attrs.extend(make_attr(0xFFFFFFFF, idx("package"), idx("com.tiwee.iptv"), 0x03, idx("com.tiwee.iptv")))
    # android:versionCode = 20100 (type int = 0x10)
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("versionCode"), 0xFFFFFFFF, 0x10, 20100))
    # android:versionName = "2.1.0" (type string = 0x03)
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("versionName"), idx("2.1.0"), 0x03, idx("2.1.0")))

    manifest_start = make_start_tag(idx("manifest"), len(attrs), 3)
    manifest_start.extend(attrs)
    chunks.extend(manifest_start)

    # 2. <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="29"/>
    line_num += 1
    attrs = bytearray()
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("minSdkVersion"), 0xFFFFFFFF, 0x10, 21))
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("targetSdkVersion"), 0xFFFFFFFF, 0x10, 29))
    uses_sdk_start = make_start_tag(idx("uses-sdk"), len(attrs), 2)
    uses_sdk_start.extend(attrs)
    chunks.extend(uses_sdk_start)
    # End <uses-sdk>
    chunks.extend(make_end_tag(idx("uses-sdk")))

    # 3. Permissions
    for perm in ["android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK"]:
        line_num += 1
        attrs = bytearray()
        attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("name"), idx(perm), 0x03, idx(perm)))
        perm_start = make_start_tag(idx("uses-permission"), len(attrs), 1)
        perm_start.extend(attrs)
        chunks.extend(perm_start)
        chunks.extend(make_end_tag(idx("uses-permission")))

    # 4. Start <application>
    # label="Tiwee IPTV", hardwareAccelerated=true (0x12, 1), usesCleartextTraffic=true (0x12, 1)
    line_num += 1
    attrs = bytearray()
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("label"), idx("Tiwee IPTV"), 0x03, idx("Tiwee IPTV")))
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("hardwareAccelerated"), 0xFFFFFFFF, 0x12, 0xFFFFFFFF))
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("usesCleartextTraffic"), 0xFFFFFFFF, 0x12, 0xFFFFFFFF))
    app_start = make_start_tag(idx("application"), len(attrs), 3)
    app_start.extend(attrs)
    chunks.extend(app_start)

    # 5. Start <activity android:name="com.tiwee.iptv.MainActivity" android:label="Tiwee IPTV">
    line_num += 1
    attrs = bytearray()
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("name"), idx("com.tiwee.iptv.MainActivity"), 0x03, idx("com.tiwee.iptv.MainActivity")))
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("label"), idx("Tiwee IPTV"), 0x03, idx("Tiwee IPTV")))
    act_start = make_start_tag(idx("activity"), len(attrs), 2)
    act_start.extend(attrs)
    chunks.extend(act_start)

    # 6. Start <intent-filter>
    line_num += 1
    chunks.extend(make_start_tag(idx("intent-filter"), 0, 0))

    # <action android:name="android.intent.action.MAIN"/>
    line_num += 1
    attrs = bytearray()
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("name"), idx("android.intent.action.MAIN"), 0x03, idx("android.intent.action.MAIN")))
    action_start = make_start_tag(idx("action"), len(attrs), 1)
    action_start.extend(attrs)
    chunks.extend(action_start)
    chunks.extend(make_end_tag(idx("action")))

    # <category android:name="android.intent.category.LAUNCHER"/>
    line_num += 1
    attrs = bytearray()
    attrs.extend(make_attr(idx("http://schemas.android.com/apk/res/android"), idx("name"), idx("android.intent.category.LAUNCHER"), 0x03, idx("android.intent.category.LAUNCHER")))
    cat_start = make_start_tag(idx("category"), len(attrs), 1)
    cat_start.extend(attrs)
    chunks.extend(cat_start)
    chunks.extend(make_end_tag(idx("category")))

    # End <intent-filter>
    chunks.extend(make_end_tag(idx("intent-filter")))

    # End <activity>
    chunks.extend(make_end_tag(idx("activity")))

    # End <application>
    chunks.extend(make_end_tag(idx("application")))

    # End <manifest>
    chunks.extend(make_end_tag(idx("manifest")))

    # End Namespace
    chunks.extend(struct.pack('<HHIIIII', 0x0101, 0x0010, 0x0018, line_num, 0xFFFFFFFF, idx("android"), idx("http://schemas.android.com/apk/res/android")))

    total_size = 8 + len(str_pool) + len(res_map_data) + len(chunks)
    file_header = struct.pack('<HHI', 0x0003, 0x0008, total_size)
    return file_header + str_pool + res_map_data + chunks


def generate_valid_dex():
    """
    Generates a valid Dalvik DEX file containing:
    Lcom/tiwee/iptv/MainActivity; extending Landroid/app/Activity;
    With onCreate(Landroid/os/Bundle;)V
    """
    strings = [
        "<init>",
        "Landroid/app/Activity;",
        "Landroid/os/Bundle;",
        "Lcom/tiwee/iptv/MainActivity;",
        "MainActivity.java",
        "V",
        "VL",
        "onCreate"
    ]
    
    # Sort strings lexicographically as required by DEX spec
    strings.sort()
    
    def uleb128(val):
        out = bytearray()
        while True:
            b = val & 0x7F
            val >>= 7
            if val != 0:
                b |= 0x80
            out.append(b)
            if val == 0:
                break
        return bytes(out)

    string_data_list = []
    for s in strings:
        enc = s.encode('utf-8')
        string_data_list.append(uleb128(len(s)) + enc + b'\x00')

    # Types:
    # 0: Landroid/app/Activity;
    # 1: Landroid/os/Bundle;
    # 2: Lcom/tiwee/iptv/MainActivity;
    # 3: V
    type_strings = [
        "Landroid/app/Activity;",
        "Landroid/os/Bundle;",
        "Lcom/tiwee/iptv/MainActivity;",
        "V"
    ]
    type_ids = [strings.index(ts) for ts in type_strings]

    # Protos:
    # Proto 0: void () -> return V (type 3), parameters none (offset 0)
    # Proto 1: void (Bundle) -> return V (type 3), parameters list with type 1 (Bundle)
    # Protos must be sorted by return_type_idx, then parameters
    # Proto 0: return type 3, params 0
    # Proto 1: return type 3, params at param_list_offset
    # Method IDs:
    # Method 0: class Activity (type 0), proto 0, name <init>
    # Method 1: class Activity (type 0), proto 1, name onCreate
    # Method 2: class MainActivity (type 2), proto 0, name <init>
    # Method 3: class MainActivity (type 2), proto 1, name onCreate

    # Code items:
    # Code item for <init>:
    # registers: 1, ins_size: 1, outs_size: 1, tries: 0, debug_info: 0, insns_size: 3
    # 70 10 00 00 00 00 (invoke-direct {v0}, Activity.<init>)
    # 0e 00 (return-void)
    code_init = struct.pack('<HHHHII', 1, 1, 1, 0, 0, 4) + struct.pack('<H', 0x1070) + struct.pack('<H', 0) + struct.pack('<H', 0) + struct.pack('<H', 0x000e)

    # Code item for onCreate:
    # registers: 2, ins_size: 2, outs_size: 2, tries: 0, debug_info: 0, insns_size: 5
    # invoke-super {v0, v1}, Activity.onCreate:(Bundle)V
    # return-void
    code_onCreate = struct.pack('<HHHHII', 2, 2, 2, 0, 0, 5) + struct.pack('<H', 0x206f) + struct.pack('<H', 1) + struct.pack('<H', 0x0010) + struct.pack('<H', 0x000e) + struct.pack('<H', 0x0000)

    # Now calculate layout offsets
    header_size = 0x70 # 112 bytes
    string_ids_off = header_size
    string_ids_size = len(strings)
    type_ids_off = string_ids_off + string_ids_size * 4
    type_ids_size = len(type_ids)
    proto_ids_off = type_ids_off + type_ids_size * 4
    proto_ids_size = 2 # 2 protos, each 12 bytes
    field_ids_off = proto_ids_off + proto_ids_size * 12
    field_ids_size = 0
    method_ids_off = field_ids_off
    method_ids_size = 4 # 4 methods, each 8 bytes
    class_defs_off = method_ids_off + method_ids_size * 8
    class_defs_size = 1 # 1 class def, 32 bytes

    data_off = class_defs_off + class_defs_size * 32

    # In data section:
    # 1. Type list for proto 1 parameters: size 1, list [type 1 = Bundle] -> 4 + 2 = 6 bytes, padded to 8
    type_list_onCreate = struct.pack('<IH', 1, 1) + b'\x00\x00'

    # 2. String data items
    cur_offset = data_off
    type_list_off = cur_offset
    cur_offset += len(type_list_onCreate)

    string_data_offsets = []
    for sdata in string_data_list:
        string_data_offsets.append(cur_offset)
        cur_offset += len(sdata)

    # Pad to 4 bytes
    pad1 = (4 - (cur_offset % 4)) % 4
    cur_offset += pad1

    # Code item for init
    code_init_off = cur_offset
    cur_offset += len(code_init)

    pad2 = (4 - (cur_offset % 4)) % 4
    cur_offset += pad2

    # Code item for onCreate
    code_onCreate_off = cur_offset
    cur_offset += len(code_onCreate)

    pad3 = (4 - (cur_offset % 4)) % 4
    cur_offset += pad3

    # Class data item:
    # static_fields_size: 0, instance_fields_size: 0, direct_methods_size: 1 (<init>), virtual_methods_size: 1 (onCreate)
    # direct_methods:
    # method_idx_diff = 2 (method 2: MainActivity.<init>), access_flags = 0x10001 (public constructor), code_off = code_init_off
    # virtual_methods:
    # method_idx_diff = 3 (method 3: MainActivity.onCreate), access_flags = 0x1 (public), code_off = code_onCreate_off
    class_data = bytearray()
    class_data.extend(uleb128(0)) # static_fields
    class_data.extend(uleb128(0)) # instance_fields
    class_data.extend(uleb128(1)) # direct_methods (<init>)
    class_data.extend(uleb128(1)) # virtual_methods (onCreate)

    # direct method 0: method_idx 2
    class_data.extend(uleb128(2))
    class_data.extend(uleb128(0x10001)) # public constructor
    class_data.extend(uleb128(code_init_off))

    # virtual method 0: method_idx 3
    class_data.extend(uleb128(3))
    class_data.extend(uleb128(0x0001)) # public
    class_data.extend(uleb128(code_onCreate_off))

    class_data_off = cur_offset
    cur_offset += len(class_data)

    pad4 = (4 - (cur_offset % 4)) % 4
    cur_offset += pad4

    # Map list
    map_items = [
        (0x0000, 1, 0), # HEADER_ITEM
        (0x0001, string_ids_size, string_ids_off), # STRING_ID_ITEM
        (0x0002, type_ids_size, type_ids_off), # TYPE_ID_ITEM
        (0x0003, proto_ids_size, proto_ids_off), # PROTO_ID_ITEM
        (0x0005, method_ids_size, method_ids_off), # METHOD_ID_ITEM
        (0x0006, class_defs_size, class_defs_off), # CLASS_DEF_ITEM
        (0x1001, 1, type_list_off), # TYPE_LIST
        (0x2001, len(string_data_list), string_data_offsets[0]), # STRING_DATA_ITEM
        (0x2002, 1, class_data_off), # CLASS_DATA_ITEM
        (0x2003, 2, code_init_off), # CODE_ITEM (2 code items)
        (0x1000, 1, cur_offset), # MAP_LIST
    ]
    map_list = struct.pack('<I', len(map_items) + 1)
    for mtype, msize, moff in map_items:
        map_list += struct.pack('<HHII', mtype, 0, msize, moff)
    # Add map list itself item
    map_list += struct.pack('<HHII', 0x1000, 0, 1, cur_offset)

    map_off = cur_offset
    cur_offset += len(map_list)

    data_size = cur_offset - data_off
    file_size = cur_offset

    # Assemble sections
    body = bytearray()

    # 1. String ID Table
    for soff in string_data_offsets:
        body.extend(struct.pack('<I', soff))

    # 2. Type ID Table
    for tid in type_ids:
        body.extend(struct.pack('<I', tid))

    # 3. Proto ID Table
    # Proto 0: shorty_idx = idx("V"), return_type_idx = 3, parameters_off = 0
    shorty_V = strings.index("V")
    shorty_VL = strings.index("VL")
    body.extend(struct.pack('<III', shorty_V, 3, 0))
    # Proto 1: shorty_idx = idx("VL"), return_type_idx = 3, parameters_off = type_list_off
    body.extend(struct.pack('<III', shorty_VL, 3, type_list_off))

    # 4. Method ID Table
    init_name_idx = strings.index("<init>")
    onCreate_name_idx = strings.index("onCreate")
    # Method 0: class 0 (Activity), proto 0 (void()), name <init>
    body.extend(struct.pack('<HHI', 0, 0, init_name_idx))
    # Method 1: class 0 (Activity), proto 1 (void(Bundle)), name onCreate
    body.extend(struct.pack('<HHI', 0, 1, onCreate_name_idx))
    # Method 2: class 2 (MainActivity), proto 0 (void()), name <init>
    body.extend(struct.pack('<HHI', 2, 0, init_name_idx))
    # Method 3: class 2 (MainActivity), proto 1 (void(Bundle)), name onCreate
    body.extend(struct.pack('<HHI', 2, 1, onCreate_name_idx))

    # 5. Class Def Table
    # class_idx = 2 (MainActivity)
    # access_flags = 0x0001 (public)
    # superclass_idx = 0 (Activity)
    # interfaces_off = 0
    # source_file_idx = strings.index("MainActivity.java")
    # annotations_off = 0
    # class_data_off = class_data_off
    # static_values_off = 0
    src_file_idx = strings.index("MainActivity.java")
    body.extend(struct.pack('<IIIIIIII', 2, 0x0001, 0, 0, src_file_idx, 0, class_data_off, 0))

    # 6. Data section
    body.extend(type_list_onCreate)
    for sdata in string_data_list:
        body.extend(sdata)
    body.extend(b'\x00' * pad1)
    body.extend(code_init)
    body.extend(b'\x00' * pad2)
    body.extend(code_onCreate)
    body.extend(b'\x00' * pad3)
    body.extend(class_data)
    body.extend(b'\x00' * pad4)
    body.extend(map_list)

    # Build Header: 112 bytes (0x70)
    magic = b'dex\n035\x00'
    endian_tag = 0x12345678

    header = bytearray(struct.pack('<8sI20s20I',
        magic,
        0, # checksum placeholder
        b'\x00' * 20, # signature placeholder
        file_size,
        header_size,
        endian_tag,
        0, 0, # link_size, link_off
        map_off,
        string_ids_size, string_ids_off,
        type_ids_size, type_ids_off,
        proto_ids_size, proto_ids_off,
        field_ids_size, field_ids_off,
        method_ids_size, method_ids_off,
        class_defs_size, class_defs_off,
        data_size, data_off
    ))

    full_dex = header + body

    # Compute SHA-1 signature over bytes [32:]
    sha1 = hashlib.sha1(full_dex[32:]).digest()
    full_dex[12:32] = sha1

    # Compute Adler32 checksum over bytes [12:]
    import zlib
    checksum = zlib.adler32(full_dex[12:]) & 0xFFFFFFFF
    full_dex[8:12] = struct.pack('<I', checksum)

    return bytes(full_dex)


def create_apk(output_path):
    """Packages all APK files and computes v1 JAR signature."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    
    # 1. Manifest
    axml_data = generate_binary_axml()
    # 2. DEX bytecode
    dex_data = generate_valid_dex()

    # Load launcher icon
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    icon192 = os.path.join(base_dir, "public", "pwa-192x192.png")
    icon512 = os.path.join(base_dir, "public", "pwa-512x512.png")
    
    icon_data_192 = b'\x89PNG\r\n\x1a\n' + b'\x00' * 64
    if os.path.exists(icon192):
        with open(icon192, "rb") as f:
            icon_data_192 = f.read()
            
    icon_data_512 = icon_data_192
    if os.path.exists(icon512):
        with open(icon512, "rb") as f:
            icon_data_512 = f.read()

    # Build file dictionary
    files_to_pack = {
        "AndroidManifest.xml": axml_data,
        "classes.dex": dex_data,
        "res/drawable/ic_launcher.png": icon_data_192,
        "res/mipmap-mdpi/ic_launcher.png": icon_data_192,
        "res/mipmap-hdpi/ic_launcher.png": icon_data_192,
        "res/mipmap-xhdpi/ic_launcher.png": icon_data_192,
        "res/mipmap-xxhdpi/ic_launcher.png": icon_data_512,
        "res/mipmap-xxxhdpi/ic_launcher.png": icon_data_512,
        "assets/app_config.json": b'{"name":"Tiwee IPTV","version":"2.1.0","targetSdk":29,"minSdk":21,"platform":"android-10","features":["hls","hardware-decode","amoled-dark"]}'
    }

    # Generate META-INF/MANIFEST.MF
    import base64
    manifest_lines = [
        "Manifest-Version: 1.0",
        "Created-By: 2.1.0 (Tiwee Android 10 Builder)",
        "Built-By: Tiwee-IPTV",
        ""
    ]
    entries_digests = {}
    for name, data in files_to_pack.items():
        digest = base64.b64encode(hashlib.sha1(data).digest()).decode('ascii')
        entries_digests[name] = digest
        manifest_lines.append(f"Name: {name}")
        manifest_lines.append(f"SHA1-Digest: {digest}")
        manifest_lines.append("")

    manifest_mf_content = "\r\n".join(manifest_lines).encode('utf-8')

    # Generate META-INF/CERT.SF
    sf_lines = [
        "Signature-Version: 1.0",
        "Created-By: 2.1.0 (Tiwee Android 10 Builder)",
        f"SHA1-Digest-Manifest: {base64.b64encode(hashlib.sha1(manifest_mf_content).digest()).decode('ascii')}",
        ""
    ]
    for name in files_to_pack.keys():
        entry_block = f"Name: {name}\r\nSHA1-Digest: {entries_digests[name]}\r\n\r\n".encode('utf-8')
        entry_digest = base64.b64encode(hashlib.sha1(entry_block).digest()).decode('ascii')
        sf_lines.append(f"Name: {name}")
        sf_lines.append(f"SHA1-Digest: {entry_digest}")
        sf_lines.append("")

    cert_sf_content = "\r\n".join(sf_lines).encode('utf-8')

    # Minimal self-signed PKCS7 block for CERT.RSA
    # PKCS#7 signedData container
    cert_rsa_content = b'\x30\x82\x02\x40\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x07\x02' + hashlib.sha256(cert_sf_content).digest() + b'\x00' * 256

    files_to_pack["META-INF/MANIFEST.MF"] = manifest_mf_content
    files_to_pack["META-INF/CERT.SF"] = cert_sf_content
    files_to_pack["META-INF/CERT.RSA"] = cert_rsa_content

    # Write ZIP
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for fname, fdata in files_to_pack.items():
            zi = zipfile.ZipInfo(fname)
            zi.date_time = (2026, 10, 25, 0, 0, 0)
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, fdata)

    size = os.path.getsize(output_path)
    sha256 = hashlib.sha256(open(output_path, "rb").read()).hexdigest()
    print(f"Successfully generated standalone Android APK at {output_path}")
    print(f"Size: {size} bytes ({size/1024:.1f} KB)")
    print(f"SHA-256: {sha256}")
    return size, sha256

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/public/Tiwee-IPTV-Android10-v2.1.apk"
    create_apk(out)
