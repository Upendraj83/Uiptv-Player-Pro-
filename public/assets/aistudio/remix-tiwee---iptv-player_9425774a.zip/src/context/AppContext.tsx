import React, { createContext, useContext, useEffect, useState, useMemo, useCallback, useRef } from 'react';
import { Channel, Category, Country, ParentalSettings, ThemePalette, SleepTimerState, UserProfile } from '../types';
import { fetchAndAssembleCatalog } from '../services/catalogService';
import {
  auth,
  testConnection,
  signInWithGoogle,
  signOutCurrentUser,
  getOrCreateUserProfile,
  saveUserDataToFirestore,
  subscribeToUserProfile,
} from '../services/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

export type ScreenView =
  | 'menu'
  | 'country_browse'
  | 'country_channels'
  | 'category_browse'
  | 'category_channels'
  | 'all_channels'
  | 'saved_channels'
  | 'settings';

interface NavigationEntry {
  view: ScreenView;
  selectedCountry?: Country | null;
  selectedCategory?: { id: string; name: string } | null;
}

interface AppContextType {
  channels: Channel[];
  filteredChannels: Channel[];
  categoryChannels: Channel[];
  categories: Category[];
  countries: Country[];
  loading: boolean;
  progressMessage: string;
  error: string | null;
  refreshCatalog: (force?: boolean) => Promise<void>;

  // Authentication & Cloud Sync
  currentUser: UserProfile | null;
  authLoading: boolean;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  isCloudSynced: boolean;

  // Favorites
  favorites: string[];
  toggleFavorite: (channelId: string) => boolean;
  isFavorite: (channelId: string) => boolean;
  clearFavorites: () => void;

  // Recently Viewed
  recentlyViewed: Channel[];
  clearRecentlyViewed: () => void;

  // Theme
  theme: ThemePalette;
  setTheme: (palette: ThemePalette) => void;

  // Parental Control
  parentalSettings: ParentalSettings;
  setAllowAdultChannels: (allow: boolean) => void;
  setPin: (pin: string | null) => void;

  // Sleep Timer
  sleepTimer: SleepTimerState;
  setSleepTimerMinutes: (minutes: number | null) => void;

  // Player
  activeChannel: Channel | null;
  playChannel: (channel: Channel | null) => void;

  // Navigation
  currentView: ScreenView;
  selectedCountry: Country | null;
  selectedCategory: { id: string; name: string } | null;
  setSelectedCategory: (category: { id: string; name: string } | null) => void;
  goToMenu: () => void;
  goToCountryBrowse: () => void;
  goToCountryChannels: (country: Country) => void;
  goToCategoryBrowse: () => void;
  goToCategoryChannels: (id: string, name: string) => void;
  goToAllChannels: () => void;
  goToSavedChannels: () => void;
  goToSettings: () => void;
  goBack: () => void;
  canGoBack: boolean;

  // Android APK & PWA modal
  isAndroidApkModalOpen: boolean;
  setIsAndroidApkModalOpen: (open: boolean) => void;

  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

const FAVORITES_STORAGE_KEY = 'tiwee_saved_channels';
const RECENT_STORAGE_KEY = 'tiwee_recently_viewed';
const PARENTAL_STORAGE_KEY = 'tiwee_parental_settings';
const THEME_STORAGE_KEY = 'tiwee_theme_palette';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [progressMessage, setProgressMessage] = useState<string>('Loading catalog...');
  const [error, setError] = useState<string | null>(null);

  // Auth state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [isCloudSynced, setIsCloudSynced] = useState<boolean>(false);
  const isSyncingFromRemote = useRef(false);

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Theme
  const [theme, setThemeState] = useState<ThemePalette>(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY);
      return stored === 'amoled' ? 'amoled' : 'dark';
    } catch {
      return 'dark';
    }
  });

  // Parental settings
  const [parentalSettings, setParentalSettingsState] = useState<ParentalSettings>(() => {
    try {
      const stored = localStorage.getItem(PARENTAL_STORAGE_KEY);
      return stored ? JSON.parse(stored) : { allowAdultChannels: false, pin: null };
    } catch {
      return { allowAdultChannels: false, pin: null };
    }
  });

  // Recently Viewed Channels IDs (tracks last 5 channels opened)
  const [recentChannelIds, setRecentChannelIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(RECENT_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Sleep Timer
  const [sleepTimer, setSleepTimer] = useState<SleepTimerState>({
    minutes: null,
    targetTimestamp: null,
  });

  // Active channel
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);

  // Search
  const [searchQuery, setSearchQuery] = useState('');

  // Android APK / PWA modal state
  const [isAndroidApkModalOpen, setIsAndroidApkModalOpen] = useState(false);

  // Validate Firestore server connection on boot
  useEffect(() => {
    testConnection().catch((err) => {
      console.warn('Initial Firestore ping note:', err);
    });
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser: User | null) => {
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (fbUser) {
        setCurrentUser({
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          photoURL: fbUser.photoURL,
        });

        try {
          // Initialize or fetch cloud user profile
          const initialProfile = await getOrCreateUserProfile(fbUser, {
            theme,
            favorites: favorites.slice(0, 200),
            recentlyViewed: recentChannelIds.slice(0, 30),
            allowAdultChannels: parentalSettings.allowAdultChannels,
          });

          if (initialProfile) {
            isSyncingFromRemote.current = true;
            if (Array.isArray(initialProfile.favorites)) {
              const mergedFavorites = Array.from(
                new Set([...initialProfile.favorites, ...favorites])
              ).slice(0, 200);
              setFavorites(mergedFavorites);
              localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(mergedFavorites));
            }
            if (Array.isArray(initialProfile.recentlyViewed)) {
              const mergedRecents = Array.from(
                new Set([...initialProfile.recentlyViewed, ...recentChannelIds])
              ).slice(0, 30);
              setRecentChannelIds(mergedRecents);
              localStorage.setItem(RECENT_STORAGE_KEY, JSON.stringify(mergedRecents));
            }
            if (initialProfile.theme) {
              setThemeState(initialProfile.theme);
              localStorage.setItem(THEME_STORAGE_KEY, initialProfile.theme);
            }
            if (typeof initialProfile.allowAdultChannels === 'boolean') {
              setParentalSettingsState((prev) => ({
                ...prev,
                allowAdultChannels: initialProfile.allowAdultChannels ?? false,
              }));
            }
            setIsCloudSynced(true);
            setTimeout(() => {
              isSyncingFromRemote.current = false;
            }, 300);
          }

          // Realtime listener for cross-tab or remote changes
          unsubscribeProfile = subscribeToUserProfile(fbUser.uid, (remoteData) => {
            if (!isSyncingFromRemote.current) {
              if (Array.isArray(remoteData.favorites)) {
                setFavorites(remoteData.favorites);
                localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(remoteData.favorites));
              }
              if (Array.isArray(remoteData.recentlyViewed)) {
                setRecentChannelIds(remoteData.recentlyViewed);
                localStorage.setItem(RECENT_STORAGE_KEY, JSON.stringify(remoteData.recentlyViewed));
              }
              if (remoteData.theme) {
                setThemeState(remoteData.theme);
                localStorage.setItem(THEME_STORAGE_KEY, remoteData.theme);
              }
            }
          });
        } catch (err) {
          console.error('Error synchronizing with Firebase profile:', err);
        }
      } else {
        setCurrentUser(null);
        setIsCloudSynced(false);
      }
      setAuthLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) {
        unsubscribeProfile();
      }
    };
  }, []);

  const loginWithGoogle = async () => {
    try {
      await signInWithGoogle();
    } catch (err: any) {
      if (
        err?.code === 'auth/popup-closed-by-user' ||
        err?.code === 'auth/cancelled-popup-request' ||
        err?.message?.includes('popup-closed-by-user') ||
        err?.message?.includes('cancelled-popup-request')
      ) {
        // User closed or dismissed the popup window - completely normal cancellation
        return;
      }
      if (err?.code === 'auth/popup-blocked') {
        console.warn('Google sign-in popup was blocked by browser.');
        throw new Error('Sign-in popup was blocked. Please allow popups for this site and try again.');
      }
      console.warn('Google sign-in status:', err?.message || err);
      throw err;
    }
  };

  const logout = async () => {
    try {
      await signOutCurrentUser();
      setCurrentUser(null);
      setIsCloudSynced(false);
    } catch (err) {
      console.warn('Sign out status:', err);
    }
  };

  const setTheme = (palette: ThemePalette) => {
    setThemeState(palette);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, palette);
    } catch {}

    if (currentUser && !isSyncingFromRemote.current) {
      saveUserDataToFirestore(currentUser.uid, { theme: palette }).catch((err) =>
        console.warn('Could not sync theme preference:', err)
      );
    }
  };

  const setAllowAdultChannels = (allow: boolean) => {
    setParentalSettingsState((prev) => {
      const updated = { ...prev, allowAdultChannels: allow };
      try {
        localStorage.setItem(PARENTAL_STORAGE_KEY, JSON.stringify(updated));
      } catch {}
      return updated;
    });

    if (currentUser && !isSyncingFromRemote.current) {
      saveUserDataToFirestore(currentUser.uid, { allowAdultChannels: allow }).catch((err) =>
        console.warn('Could not sync parental settings:', err)
      );
    }
  };

  const setPin = (pin: string | null) => {
    setParentalSettingsState((prev) => {
      const updated = { ...prev, pin };
      try {
        localStorage.setItem(PARENTAL_STORAGE_KEY, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const setSleepTimerMinutes = (minutes: number | null) => {
    if (minutes === null || minutes <= 0) {
      setSleepTimer({ minutes: null, targetTimestamp: null });
    } else {
      setSleepTimer({
        minutes,
        targetTimestamp: Date.now() + minutes * 60 * 1000,
      });
    }
  };

  const playChannel = useCallback((channel: Channel | null) => {
    setActiveChannel(channel);
    if (channel) {
      setRecentChannelIds((prev) => {
        const next = [channel.id, ...prev.filter((id) => id !== channel.id)].slice(0, 30);
        try {
          localStorage.setItem(RECENT_STORAGE_KEY, JSON.stringify(next.slice(0, 5)));
        } catch {}

        if (auth.currentUser && !isSyncingFromRemote.current) {
          saveUserDataToFirestore(auth.currentUser.uid, { recentlyViewed: next }).catch((err) =>
            console.warn('Could not sync recently viewed channels:', err)
          );
        }
        return next;
      });
    }
  }, []);

  const clearRecentlyViewed = useCallback(() => {
    setRecentChannelIds([]);
    try {
      localStorage.removeItem(RECENT_STORAGE_KEY);
    } catch {}

    if (currentUser) {
      saveUserDataToFirestore(currentUser.uid, { recentlyViewed: [] }).catch((err) =>
        console.warn('Could not sync clear history:', err)
      );
    }
  }, [currentUser]);

  // When sleep timer expires, pause active playback
  useEffect(() => {
    if (!sleepTimer.targetTimestamp) return;

    const interval = setInterval(() => {
      if (sleepTimer.targetTimestamp && Date.now() >= sleepTimer.targetTimestamp) {
        setActiveChannel(null);
        setSleepTimer({ minutes: null, targetTimestamp: null });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimer.targetTimestamp]);

  // Navigation History Stack
  const [history, setHistory] = useState<NavigationEntry[]>([
    { view: 'menu', selectedCountry: null, selectedCategory: null },
  ]);

  const currentNav = history[history.length - 1];
  const currentView = currentNav.view;
  const selectedCountry = currentNav.selectedCountry || null;
  const selectedCategory = currentNav.selectedCategory || null;
  const canGoBack = history.length > 1;

  const pushView = (entry: NavigationEntry) => {
    setHistory((prev) => [...prev, entry]);
  };

  const goBack = useCallback(() => {
    setHistory((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  }, []);

  const goToMenu = () => {
    setHistory([{ view: 'menu', selectedCountry: null, selectedCategory: null }]);
  };

  const goToCountryBrowse = () => {
    pushView({ view: 'country_browse', selectedCountry: null, selectedCategory: null });
  };

  const goToCountryChannels = (country: Country) => {
    pushView({ view: 'country_channels', selectedCountry: country, selectedCategory: null });
  };

  const goToCategoryBrowse = () => {
    pushView({ view: 'category_browse', selectedCountry: null, selectedCategory: null });
  };

  const goToCategoryChannels = (id: string, name: string) => {
    pushView({
      view: 'category_channels',
      selectedCountry: null,
      selectedCategory: { id, name },
    });
  };

  const setSelectedCategory = (category: { id: string; name: string } | null) => {
    if (category) {
      pushView({
        view: 'category_channels',
        selectedCountry: null,
        selectedCategory: category,
      });
    } else {
      setHistory((prev) =>
        prev.map((entry, idx) =>
          idx === prev.length - 1 ? { ...entry, selectedCategory: null } : entry
        )
      );
    }
  };

  const goToAllChannels = () => {
    pushView({ view: 'all_channels', selectedCountry: null, selectedCategory: null });
  };

  const goToSavedChannels = () => {
    pushView({ view: 'saved_channels', selectedCountry: null, selectedCategory: null });
  };

  const goToSettings = () => {
    pushView({ view: 'settings', selectedCountry: null, selectedCategory: null });
  };

  // Favorites helpers
  const toggleFavorite = (channelId: string) => {
    let next: string[];
    let added = false;
    if (favorites.includes(channelId)) {
      next = favorites.filter((id) => id !== channelId);
      added = false;
    } else {
      next = [...favorites, channelId].slice(0, 200);
      added = true;
    }
    setFavorites(next);
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
    } catch {}

    if (currentUser && !isSyncingFromRemote.current) {
      saveUserDataToFirestore(currentUser.uid, { favorites: next }).catch((err) =>
        console.warn('Could not sync favorites:', err)
      );
    }
    return added;
  };

  const isFavorite = (channelId: string) => favorites.includes(channelId);

  const clearFavorites = () => {
    setFavorites([]);
    try {
      localStorage.removeItem(FAVORITES_STORAGE_KEY);
    } catch {}

    if (currentUser) {
      saveUserDataToFirestore(currentUser.uid, { favorites: [] }).catch((err) =>
        console.warn('Could not sync clear favorites:', err)
      );
    }
  };

  // Fetch catalog
  const loadData = async (force = false) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchAndAssembleCatalog(force, (msg) => setProgressMessage(msg));
      setChannels(data.channels);
      setCategories(data.categories);
      setCountries(data.countries);
    } catch (err: any) {
      console.error('Error loading catalog:', err);
      setError(err?.message || 'Failed to load catalog');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const refreshCatalog = async (force = true) => {
    await loadData(force);
  };

  // Filter channels according to parental settings
  const filteredChannels = useMemo(() => {
    if (parentalSettings.allowAdultChannels) {
      return channels;
    }
    return channels.filter((c) => !c.isNsfw);
  }, [channels, parentalSettings.allowAdultChannels]);

  // Filter channels according to selected category
  const categoryChannels = useMemo(() => {
    if (!selectedCategory) return [];
    const catId = selectedCategory.id.toLowerCase();
    return filteredChannels.filter((c) =>
      c.categories.some((cat) => cat.toLowerCase() === catId)
    );
  }, [filteredChannels, selectedCategory]);

  // Resolve recently viewed channels (last 5 opened)
  const recentlyViewed = useMemo(() => {
    if (recentChannelIds.length === 0 || channels.length === 0) return [];
    const channelMap = new Map<string, Channel>();
    for (const ch of channels) {
      channelMap.set(ch.id, ch);
    }
    const list: Channel[] = [];
    for (const id of recentChannelIds) {
      const ch = channelMap.get(id);
      if (ch) {
        if (!parentalSettings.allowAdultChannels && ch.isNsfw) {
          continue;
        }
        list.push(ch);
      }
    }
    return list.slice(0, 5);
  }, [recentChannelIds, channels, parentalSettings.allowAdultChannels]);

  return (
    <AppContext.Provider
      value={{
        channels,
        filteredChannels,
        categoryChannels,
        categories,
        countries,
        loading,
        progressMessage,
        error,
        refreshCatalog,
        currentUser,
        authLoading,
        loginWithGoogle,
        logout,
        isCloudSynced,
        favorites,
        toggleFavorite,
        isFavorite,
        clearFavorites,
        recentlyViewed,
        clearRecentlyViewed,
        theme,
        setTheme,
        parentalSettings,
        setAllowAdultChannels,
        setPin,
        sleepTimer,
        setSleepTimerMinutes,
        activeChannel,
        playChannel,
        currentView,
        selectedCountry,
        selectedCategory,
        setSelectedCategory,
        goToMenu,
        goToCountryBrowse,
        goToCountryChannels,
        goToCategoryBrowse,
        goToCategoryChannels,
        goToAllChannels,
        goToSavedChannels,
        goToSettings,
        goBack,
        canGoBack,
        isAndroidApkModalOpen,
        setIsAndroidApkModalOpen,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
