import React, { useState } from 'react';
import { Lock, Shield, X, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ParentalControlModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { parentalSettings, setAllowAdultChannels, setPin } = useApp();

  const [pinDialogMode, setPinDialogMode] = useState<
    'verify_toggle' | 'verify_remove' | 'verify_change' | 'set_new' | null
  >(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const handleToggleSwitch = () => {
    if (parentalSettings.pin) {
      setPinDialogMode('verify_toggle');
      setPinInput('');
      setPinError('');
    } else {
      setAllowAdultChannels(!parentalSettings.allowAdultChannels);
    }
  };

  const handleRemovePin = () => {
    if (parentalSettings.pin) {
      setPinDialogMode('verify_remove');
      setPinInput('');
      setPinError('');
    }
  };

  const handleChangeOrSetPin = () => {
    if (parentalSettings.pin) {
      setPinDialogMode('verify_change');
    } else {
      setPinDialogMode('set_new');
    }
    setPinInput('');
    setPinError('');
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.length !== 4) {
      setPinError('PIN must be exactly 4 digits');
      return;
    }

    if (pinDialogMode === 'verify_toggle') {
      if (pinInput === parentalSettings.pin) {
        setAllowAdultChannels(!parentalSettings.allowAdultChannels);
        setPinDialogMode(null);
      } else {
        setPinError('Wrong PIN');
      }
    } else if (pinDialogMode === 'verify_remove') {
      if (pinInput === parentalSettings.pin) {
        setPin(null);
        setPinDialogMode(null);
      } else {
        setPinError('Wrong PIN');
      }
    } else if (pinDialogMode === 'verify_change') {
      if (pinInput === parentalSettings.pin) {
        setPinDialogMode('set_new');
        setPinInput('');
        setPinError('');
      } else {
        setPinError('Wrong PIN');
      }
    } else if (pinDialogMode === 'set_new') {
      setPin(pinInput);
      setPinDialogMode(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-[#262433] border border-white/10 rounded-2xl p-5 max-w-md w-full shadow-2xl relative">
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-[#9c4af5]" />
            <h3 className="text-white font-bold text-lg">Parental Control</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/50 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Setting Items */}
        <div className="space-y-4">
          {/* Switch Adult Channels */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-white/5 border border-white/5">
            <div>
              <p className="text-white text-sm font-semibold">Show adult channels</p>
              <p className="text-white/50 text-xs mt-0.5">
                {parentalSettings.allowAdultChannels
                  ? 'Adult channels appear in every list.'
                  : 'Adult channels are hidden everywhere.'}
              </p>
            </div>
            <button
              onClick={handleToggleSwitch}
              className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                parentalSettings.allowAdultChannels ? 'bg-[#9c4af5]' : 'bg-white/20'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  parentalSettings.allowAdultChannels ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Set / Change PIN */}
          <div
            onClick={handleChangeOrSetPin}
            className="flex items-center justify-between p-3.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer transition-colors"
          >
            <div>
              <p className="text-white text-sm font-semibold">
                {parentalSettings.pin ? 'Change PIN' : 'Set a PIN'}
              </p>
              <p className="text-white/50 text-xs mt-0.5">
                {parentalSettings.pin
                  ? 'A PIN is required to change the setting above.'
                  : 'Without a PIN anyone can flip the setting above.'}
              </p>
            </div>
            <Lock className="w-4 h-4 text-white/50" />
          </div>

          {/* Remove PIN */}
          {parentalSettings.pin && (
            <div
              onClick={handleRemovePin}
              className="flex items-center justify-between p-3.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer transition-colors"
            >
              <div>
                <p className="text-white text-sm font-semibold">Remove PIN</p>
                <p className="text-white/50 text-xs mt-0.5">Disables PIN requirement.</p>
              </div>
              <X className="w-4 h-4 text-red-400" />
            </div>
          )}
        </div>

        {/* PIN Input Sub-Dialog */}
        {pinDialogMode && (
          <div className="absolute inset-0 bg-[#262433] rounded-2xl p-5 flex flex-col justify-between z-10">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-white font-bold text-base">
                  {pinDialogMode === 'set_new' ? 'Choose 4-Digit PIN' : 'Enter PIN'}
                </h4>
                <button
                  onClick={() => setPinDialogMode(null)}
                  className="p-1 rounded-lg text-white/50 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handlePinSubmit} className="space-y-4">
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  autoFocus
                  value={pinInput}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setPinInput(val);
                    setPinError('');
                  }}
                  placeholder="••••"
                  className="w-full text-center text-3xl tracking-[1em] py-3 rounded-xl bg-white/10 border border-white/20 text-white focus:outline-none focus:ring-2 focus:ring-[#9c4af5]"
                />
                {pinError && <p className="text-red-400 text-xs text-center">{pinError}</p>}

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setPinDialogMode(null)}
                    className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs hover:bg-white/15"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#9c4af5] text-white text-xs font-semibold hover:bg-[#8630df]"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Confirm
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
