import React, { useState } from 'react';
import {
  Moon,
  Clock,
  ExternalLink,
  RefreshCw,
  Send,
  Github,
  Check,
  Cloud,
  CloudCheck,
  LogIn,
  LogOut,
  User,
  Smartphone,
  Download,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { kTelegramUrl, kGithubUrl } from '../constants';
import { ParentalControlModal } from './ParentalControlModal';

export const SettingsView: React.FC = () => {
  const {
    favorites,
    theme,
    setTheme,
    sleepTimer,
    setSleepTimerMinutes,
    refreshCatalog,
    goToSavedChannels,
    parentalSettings,
    currentUser,
    authLoading,
    loginWithGoogle,
    logout,
    isCloudSynced,
    setIsAndroidApkModalOpen,
  } = useApp();

  const [showParentalModal, setShowParentalModal] = useState(false);
  const [showSleepModal, setShowSleepModal] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshSuccess, setRefreshSuccess] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const cardBg =
    theme === 'amoled'
      ? 'bg-[#121212] hover:bg-[#1a1a1a] border-white/5'
      : 'bg-[#262433] hover:bg-[#2d2b3d] border-white/5';

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setRefreshSuccess(false);
    try {
      await refreshCatalog(true);
      setRefreshSuccess(true);
      setTimeout(() => setRefreshSuccess(false), 3000);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      if (
        err?.code === 'auth/popup-closed-by-user' ||
        err?.code === 'auth/cancelled-popup-request' ||
        err?.message?.includes('popup-closed-by-user') ||
        err?.message?.includes('cancelled-popup-request')
      ) {
        // Normal user cancellation, do not treat as error
        return;
      }
      console.warn('Sign-in status:', err);
      setAuthError(err?.message || 'Could not sign in with Google');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (err: any) {
      console.warn('Sign-out status:', err);
    }
  };

  const sleepDurations = [null, 15, 30, 45, 60, 90, 120];

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      <div className="mb-4">
        <h2 className="text-white text-xl font-bold">Settings</h2>
        <p className="text-xs text-gray-400">Configure playback, cloud sync, theme & controls</p>
      </div>

      {/* Firebase Cloud Sync Card */}
      <div
        className={`mb-3 p-4 rounded-[22px] ${
          theme === 'amoled' ? 'bg-[#121212] border-white/10' : 'bg-[#262433] border-white/10'
        } border relative overflow-hidden`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            {currentUser?.photoURL ? (
              <img
                src={currentUser.photoURL}
                alt={currentUser.displayName || 'User'}
                className="w-12 h-12 rounded-2xl object-cover ring-2 ring-[#9c4af5]/40"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#9c4af5] to-[#6d28d9] flex items-center justify-center text-white shadow-lg shadow-[#9c4af5]/20">
                <Cloud className="w-6 h-6" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white text-sm font-bold">
                  {currentUser ? currentUser.displayName || 'Google Account' : 'Cloud Sync (Firestore)'}
                </h3>
                {currentUser && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Synced
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-400">
                {currentUser
                  ? currentUser.email || 'Favorites and history backed up to cloud'
                  : 'Sign in to sync favorites and history across all your devices'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {currentUser ? (
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white text-xs font-semibold transition-all border border-white/5"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            ) : (
              <button
                onClick={handleGoogleLogin}
                disabled={isLoggingIn || authLoading}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] active:scale-95 text-white text-xs font-semibold transition-all shadow-md shadow-[#9c4af5]/20"
              >
                <LogIn className="w-3.5 h-3.5" />
                {isLoggingIn ? 'Connecting...' : 'Sign in with Google'}
              </button>
            )}
          </div>
        </div>

        {authError && (
          <p className="mt-2 text-xs text-red-400 bg-red-500/10 p-2 rounded-lg border border-red-500/20">
            {authError}
          </p>
        )}
      </div>

      {/* Android 10 Mobile App & APK Banner Card */}
      <div
        className={`mb-3 p-4 rounded-[22px] ${
          theme === 'amoled'
            ? 'bg-[#121212] border-[#3DDC84]/20'
            : 'bg-gradient-to-r from-[#19221e] via-[#211e2f] to-[#1f1a2e] border-[#3DDC84]/25'
        } border relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg shadow-black/20`}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#3DDC84]/15 border border-[#3DDC84]/30 flex items-center justify-center text-[#3DDC84] shrink-0 shadow-md shadow-[#3DDC84]/10">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white text-sm font-bold">Android 10 Mobile Standalone APK</h3>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#3DDC84]/20 text-[#3DDC84] border border-[#3DDC84]/30">
                Android 10+
              </span>
            </div>
            <p className="text-xs text-gray-300 mt-0.5">
              One-touch standalone APK download, hardware decoding & WebAPK system integration
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <a
            href="/Tiwee-IPTV-Android10-v2.1.apk"
            download="Tiwee-IPTV-Android10-v2.1.apk"
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#3DDC84] hover:bg-[#34c776] active:scale-95 text-black text-xs font-bold transition-all shadow-md shadow-[#3DDC84]/25"
            title="Download Tiwee-IPTV-Android10-v2.1.apk directly"
          >
            <Download className="w-4 h-4" />
            <span>Download APK</span>
          </a>
          <button
            onClick={() => setIsAndroidApkModalOpen(true)}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 active:scale-95 text-white text-xs font-semibold transition-all"
            title="Open installation guide and QR code"
          >
            <Smartphone className="w-4 h-4 text-purple-400" />
            <span>Guide</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {/* Saved Shows */}
        <div
          onClick={goToSavedChannels}
          role="button"
          tabIndex={0}
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-amber-400/10 flex items-center justify-center">
              <img src="/icons/saved.svg" alt="" className="w-6 h-6 object-contain" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Saved shows</h3>
              <p className="text-xs text-gray-400">Bookmarks</p>
            </div>
          </div>
          {favorites.length > 0 && (
            <span className="px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold font-mono">
              {favorites.length}
            </span>
          )}
        </div>

        {/* Theme Palette */}
        <div
          onClick={() => setTheme(theme === 'dark' ? 'amoled' : 'dark')}
          role="button"
          tabIndex={0}
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-purple-500/10 flex items-center justify-center text-[#9c4af5]">
              <Moon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Theme</h3>
              <p className="text-xs text-gray-400">
                {theme === 'amoled' ? 'AMOLED True Black' : 'Dark Purple'}
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-xl bg-white/10 text-white text-xs font-semibold uppercase">
            {theme}
          </span>
        </div>

        {/* Sleep Timer */}
        <div
          onClick={() => setShowSleepModal(true)}
          role="button"
          tabIndex={0}
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-400">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Sleep timer</h3>
              <p className="text-xs text-gray-400">
                {sleepTimer.minutes ? `${sleepTimer.minutes} minutes active` : 'Off'}
              </p>
            </div>
          </div>
          <img src="/icons/alarm.svg" alt="" className="w-5 h-5 opacity-60" />
        </div>

        {/* Parental Control */}
        <div
          onClick={() => setShowParentalModal(true)}
          role="button"
          tabIndex={0}
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-red-500/10 flex items-center justify-center">
              <img
                src="/icons/parent_lock.svg"
                alt=""
                className={`w-6 h-6 ${
                  parentalSettings.allowAdultChannels ? 'opacity-80' : 'filter-green'
                }`}
              />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Parental control</h3>
              <p className="text-xs text-gray-400">
                {parentalSettings.allowAdultChannels ? 'Adult unlocked' : 'Adult hidden'}
              </p>
            </div>
          </div>
          <span
            className={`w-3 h-3 rounded-full ${
              parentalSettings.allowAdultChannels ? 'bg-amber-400' : 'bg-emerald-400'
            }`}
          />
        </div>

        {/* Refresh / Check for Updates */}
        <div
          onClick={handleRefresh}
          role="button"
          tabIndex={0}
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Refresh Catalog</h3>
              <p className="text-xs text-gray-400">
                {refreshSuccess ? 'Catalog updated!' : 'Fetch latest IPTV streams'}
              </p>
            </div>
          </div>
          <img src="/icons/update.svg" alt="" className="w-5 h-5 opacity-60" />
        </div>

        {/* Telegram Community */}
        <a
          href={kTelegramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#0088cc]/15 flex items-center justify-center text-[#0088cc]">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">Telegram</h3>
              <p className="text-xs text-gray-400">@Neffex97</p>
            </div>
          </div>
          <ExternalLink className="w-4 h-4 text-white/40" />
        </a>

        {/* GitHub Repository */}
        <a
          href={kGithubUrl}
          target="_blank"
          rel="noopener noreferrer"
          className={`p-4 rounded-[22px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] flex items-center justify-between min-h-[90px]`}
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-white">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold">GitHub</h3>
              <p className="text-xs text-gray-400">neffex97/tiwee</p>
            </div>
          </div>
          <ExternalLink className="w-4 h-4 text-white/40" />
        </a>
      </div>

      {/* Sleep Timer Dialog */}
      {showSleepModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#262433] border border-white/10 rounded-2xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="text-white font-bold text-base mb-1">Set Sleep Timer</h3>
            <p className="text-white/50 text-xs mb-4">
              Automatically pauses live streaming after selected duration.
            </p>

            <div className="grid grid-cols-2 gap-2 mb-5">
              {sleepDurations.map((duration) => {
                const isCurrent = sleepTimer.minutes === duration;
                return (
                  <button
                    key={duration ?? 'off'}
                    onClick={() => {
                      setSleepTimerMinutes(duration);
                      setShowSleepModal(false);
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
                      isCurrent
                        ? 'bg-[#9c4af5] text-white'
                        : 'bg-white/5 text-white/80 hover:bg-white/10'
                    }`}
                  >
                    <span>{duration ? `${duration} min` : 'Turn off'}</span>
                    {isCurrent && <Check className="w-3.5 h-3.5" />}
                  </button>
                );
              })}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowSleepModal(false)}
                className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs hover:bg-white/15"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Parental Control Dialog */}
      {showParentalModal && (
        <ParentalControlModal onClose={() => setShowParentalModal(false)} />
      )}
    </div>
  );
};
