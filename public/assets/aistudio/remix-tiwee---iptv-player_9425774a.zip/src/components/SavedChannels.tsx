import React, { useMemo, useState } from 'react';
import { Heart, Trash2, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TvCard } from './TvCard';

export const SavedChannels: React.FC = () => {
  const { channels, favorites, clearFavorites, goToAllChannels } = useApp();
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const [search, setSearch] = useState('');

  const savedList = useMemo(() => {
    const set = new Set(favorites);
    return channels.filter((c) => set.has(c.id));
  }, [channels, favorites]);

  const displayedList = useMemo(() => {
    if (!search.trim()) return savedList;
    const q = search.toLowerCase().trim();
    return savedList.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.description && c.description.toLowerCase().includes(q)) ||
        c.country.toLowerCase().includes(q)
    );
  }, [savedList, search]);

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-white text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-rose-500 fill-rose-500 filter drop-shadow" />
            Favorites
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            {savedList.length} {savedList.length === 1 ? 'channel' : 'channels'} saved
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {savedList.length > 0 && (
            <>
              {/* Search within favorites */}
              <div className="relative">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Filter favorites..."
                  className="w-40 sm:w-56 px-3 py-1.5 pl-8 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-rose-500 transition-all"
                />
                <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
              </div>

              {/* Clear button */}
              <button
                onClick={() => setShowConfirmClear(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold transition-all active:scale-95"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove all</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Grid or Empty */}
      <div className="flex-1 overflow-y-auto pb-8">
        {savedList.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center p-6">
            <div className="w-16 h-16 rounded-3xl bg-rose-500/10 flex items-center justify-center mb-3 text-rose-400">
              <Heart className="w-8 h-8 fill-rose-500/30 text-rose-500" />
            </div>
            <h3 className="text-white text-base font-semibold mb-1">No favorites yet</h3>
            <p className="text-white/40 text-xs max-w-xs mb-4">
              Tap the heart on any channel tile to add it to your Favorites list for quick access anytime.
            </p>
            <button
              onClick={goToAllChannels}
              className="px-4 py-2 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-xs font-semibold transition-all active:scale-95 shadow-md shadow-[#9c4af5]/20"
            >
              Discover Channels
            </button>
          </div>
        ) : displayedList.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            <p>No favorites matching &ldquo;{search}&rdquo;</p>
            <button
              onClick={() => setSearch('')}
              className="mt-2 text-xs text-rose-400 hover:underline"
            >
              Clear filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {displayedList.map((channel) => (
              <TvCard key={channel.id} channel={channel} />
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {showConfirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-[#262433] border border-white/10 rounded-2xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="text-white font-bold text-base mb-2">Clear all favorites?</h3>
            <p className="text-white/60 text-xs mb-5">
              This will remove all {savedList.length} channels from your favorites list.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowConfirmClear(false)}
                className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs font-medium hover:bg-white/15"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearFavorites();
                  setShowConfirmClear(false);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700"
              >
                Remove all
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
