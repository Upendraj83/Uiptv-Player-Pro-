import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TvCard } from './TvCard';

export const CountryChannels: React.FC = () => {
  const { filteredChannels, selectedCountry } = useApp();
  const [search, setSearch] = useState('');

  const countryChannels = useMemo(() => {
    if (!selectedCountry) return [];
    const code = selectedCountry.code.toUpperCase();
    return filteredChannels.filter((c) => (c.country || '').toUpperCase() === code);
  }, [filteredChannels, selectedCountry]);

  const displayedChannels = useMemo(() => {
    if (!search.trim()) return countryChannels;
    const q = search.toLowerCase();
    return countryChannels.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.description && c.description.toLowerCase().includes(q)) ||
        c.altNames.some((alt) => alt.toLowerCase().includes(q))
    );
  }, [countryChannels, search]);

  if (!selectedCountry) return null;

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <span className="text-2xl">{selectedCountry.flag}</span>
          <div>
            <h2 className="text-white text-lg font-bold leading-tight">
              {selectedCountry.name}
            </h2>
            <p className="text-xs text-gray-400">
              {countryChannels.length.toLocaleString()} channels available
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search in ${selectedCountry.name}...`}
            className="w-48 sm:w-64 px-3 py-1.5 pl-8 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5]"
          />
          <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto pb-8">
        {displayedChannels.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            No channels found matching "{search}"
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {displayedChannels.map((channel) => (
              <TvCard key={channel.id} channel={channel} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
