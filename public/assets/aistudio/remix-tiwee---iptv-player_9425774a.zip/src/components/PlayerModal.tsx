import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import {
  ArrowLeft,
  Tv,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  RefreshCw,
  Play,
  Pause,
  Layers,
  Clock,
} from 'lucide-react';
import { Channel } from '../types';
import { useApp } from '../context/AppContext';

export const PlayerModal: React.FC<{ channel: Channel; onClose: () => void }> = ({
  channel,
  onClose,
}) => {
  const { sleepTimer } = useApp();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [sourceIndex, setSourceIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [exhausted, setExhausted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSourcesMenu, setShowSourcesMenu] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef<number | null>(null);

  const streams = channel.streams;
  const currentStream = streams[sourceIndex];

  // Auto hide controls
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      window.clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = window.setTimeout(() => {
      setShowControls(false);
    }, 3500);
  };

  const playSource = (index: number) => {
    if (index >= streams.length) {
      setExhausted(true);
      setIsLoading(false);
      setErrorMessage(
        streams.length === 1
          ? 'The only source for this channel is offline.'
          : `All ${streams.length} sources for this channel are offline.`
      );
      return;
    }

    setSourceIndex(index);
    setIsLoading(true);
    setErrorMessage(null);

    const stream = streams[index];
    const video = videoRef.current;
    if (!video) return;

    // Destroy existing HLS instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const isHlsStream =
      stream.url.includes('.m3u8') ||
      stream.url.includes('m3u') ||
      stream.url.includes('/hls/') ||
      !stream.url.includes('.mp4');

    if (isHlsStream && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 30,
        manifestLoadingTimeOut: 10000,
        manifestLoadingMaxRetry: 2,
        levelLoadingTimeOut: 10000,
        levelLoadingMaxRetry: 2,
        fragLoadingTimeOut: 10000,
        fragLoadingMaxRetry: 2,
      });
      hlsRef.current = hls;

      hls.loadSource(stream.url);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        video.play().catch(() => {
          setIsPlaying(false);
        });
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          console.warn(`Stream source ${index + 1} failed:`, data.details);
          hls.destroy();
          hlsRef.current = null;
          // Fall through to next source
          playNextSource(index);
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native Safari HLS
      video.src = stream.url;
      video.play().catch(() => setIsPlaying(false));
    } else {
      // Direct stream
      video.src = stream.url;
      video.play().catch(() => setIsPlaying(false));
    }
  };

  const playNextSource = (failedIndex: number) => {
    const next = failedIndex + 1;
    if (next < streams.length) {
      console.log(`Tiwee: stream ${failedIndex + 1} failed, trying source ${next + 1}/${streams.length}`);
      playSource(next);
    } else {
      setExhausted(true);
      setIsLoading(false);
      setErrorMessage(
        streams.length === 1
          ? 'The only source for this channel is offline.'
          : `All ${streams.length} sources for this channel are offline.`
      );
    }
  };

  useEffect(() => {
    playSource(0);

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [channel.id]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const retryPlayback = () => {
    setExhausted(false);
    playSource(0);
  };

  // Sleep timer display
  const sleepTimeRemaining = sleepTimer.targetTimestamp
    ? Math.max(0, Math.ceil((sleepTimer.targetTimestamp - Date.now()) / (1000 * 60)))
    : null;

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="fixed inset-0 z-50 bg-black flex flex-col justify-between overflow-hidden select-none"
    >
      {/* Video surface */}
      <div className="relative w-full h-full flex items-center justify-center bg-black">
        <video
          ref={videoRef}
          playsInline
          autoPlay
          onPlaying={() => {
            setIsPlaying(true);
            setIsLoading(false);
          }}
          onWaiting={() => setIsLoading(true)}
          onError={() => {
            if (!hlsRef.current) {
              playNextSource(sourceIndex);
            }
          }}
          className="w-full h-full max-h-screen object-contain"
        />

        {/* Loading spinner */}
        {isLoading && !exhausted && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-[2px] pointer-events-none">
            <div className="w-14 h-14 border-4 border-[#9c4af5]/20 border-t-[#9c4af5] rounded-full animate-spin shadow-lg mb-3" />
            <p className="text-white/80 text-sm font-medium">Connecting to stream...</p>
            {streams.length > 1 && (
              <p className="text-white/50 text-xs mt-1">
                Source {sourceIndex + 1} of {streams.length}
              </p>
            )}
          </div>
        )}

        {/* Exhausted / Offline error view */}
        {exhausted && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 p-6 text-center z-20">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
              <Tv className="w-8 h-8 text-white/50" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">{channel.name}</h2>
            <p className="text-white/60 text-sm max-w-md mb-6">
              {errorMessage || 'This channel could not be played at this time.'}
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={retryPlayback}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-sm font-medium transition-all active:scale-95 shadow-lg shadow-[#9c4af5]/25"
              >
                <RefreshCw className="w-4 h-4" />
                Retry
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition-all active:scale-95"
              >
                Return to Catalog
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Top Header Overlay */}
      <div
        className={`absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent flex items-center justify-between transition-opacity duration-300 z-30 ${
          showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all active:scale-95 backdrop-blur-md"
            title="Back"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            {channel.logo && (
              <img
                src={channel.logo}
                alt=""
                className="w-7 h-7 object-contain bg-white/10 rounded p-0.5"
              />
            )}
            <div>
              <h3 className="text-white font-semibold text-sm sm:text-base leading-tight">
                {channel.name}
              </h3>
              <div className="flex items-center gap-2 text-xs text-white/60">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  LIVE
                </span>
                {currentStream?.quality && (
                  <span className="px-1.5 py-0.2 rounded bg-white/10 text-[10px] font-bold uppercase">
                    {currentStream.quality}
                  </span>
                )}
                {streams.length > 1 && (
                  <span>
                    Source {sourceIndex + 1}/{streams.length}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {sleepTimeRemaining !== null && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#9c4af5]/20 border border-[#9c4af5]/40 text-purple-200 text-xs backdrop-blur-md">
              <Clock className="w-3.5 h-3.5 text-[#9c4af5]" />
              <span>{sleepTimeRemaining}m sleep timer</span>
            </div>
          )}

          {/* Sources Dropdown */}
          {streams.length > 1 && (
            <div className="relative">
              <button
                onClick={() => setShowSourcesMenu(!showSourcesMenu)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium backdrop-blur-md transition-all"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Sources ({streams.length})</span>
              </button>

              {showSourcesMenu && (
                <div className="absolute right-0 top-full mt-2 w-48 rounded-xl bg-[#262433] border border-white/10 p-1.5 shadow-2xl backdrop-blur-xl z-40">
                  <p className="px-2 py-1 text-[11px] font-semibold text-white/40 uppercase tracking-wider">
                    Available Sources
                  </p>
                  {streams.map((stream, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setShowSourcesMenu(false);
                        playSource(idx);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs text-left transition-colors ${
                        sourceIndex === idx
                          ? 'bg-[#9c4af5] text-white font-medium'
                          : 'text-white/80 hover:bg-white/5'
                      }`}
                    >
                      <span className="truncate max-w-[120px]">
                        {stream.title || `Stream ${idx + 1}`}
                      </span>
                      {stream.quality && (
                        <span className="text-[10px] uppercase opacity-75">{stream.quality}</span>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls Overlay */}
      <div
        className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-center justify-between transition-opacity duration-300 z-30 ${
          showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={togglePlay}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-all active:scale-90"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
          </button>

          <div className="flex items-center gap-2 group">
            <button
              onClick={toggleMute}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-all active:scale-90"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-5 h-5" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-20 sm:w-28 accent-[#9c4af5] cursor-pointer"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => playSource(sourceIndex)}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-all active:scale-90"
            title="Reload Stream"
          >
            <RefreshCw className="w-5 h-5" />
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-all active:scale-90"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
