import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { MENU_CARD_DEFAULTS } from '../constants';
import {
  Globe,
  Layers,
  ChevronRight,
  Sparkles,
  History,
  RotateCcw,
  Heart,
  Search,
  X,
  ArrowDownAZ,
  ArrowUpDown,
} from 'lucide-react';
import { TvCard } from './TvCard';

export const MenuGrid: React.FC = () => {
  const {
    filteredChannels,
    categories,
    goToCountryBrowse,
    goToCategoryBrowse,
    goToCategoryChannels,
    goToSavedChannels,
    favorites,
    recentlyViewed,
    clearRecentlyViewed,
    theme,
  } = useApp();

  const [categorySearch, setCategorySearch] = useState('');
  const [sortAlphabetical, setSortAlphabetical] = useState(false);

  // Pre-calculate channel counts by category
  const categoryChannelCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const channel of filteredChannels) {
      for (const cat of channel.categories) {
        counts[cat] = (counts[cat] || 0) + 1;
      }
    }
    return counts;
  }, [filteredChannels]);

  // Map category IDs to names
  const categoryNames = useMemo(() => {
    const map: Record<string, string> = {};
    for (const cat of categories) {
      map[cat.id] = cat.name;
    }
    return map;
  }, [categories]);

  // Favorite channels list for main menu quick access
  const favoriteChannelsList = useMemo(() => {
    if (favorites.length === 0 || filteredChannels.length === 0) return [];
    const set = new Set(favorites);
    return filteredChannels.filter((c) => set.has(c.id));
  }, [favorites, filteredChannels]);

  // Processed category cards with search and alphabetical sorting
  const processedCategoryCards = useMemo(() => {
    const cards = MENU_CARD_DEFAULTS.map((card) => {
      const isLive = card.categoryId === null;
      const count = isLive
        ? filteredChannels.length
        : categoryChannelCounts[card.categoryId!] || 0;
      const displayName = isLive
        ? card.title
        : categoryNames[card.categoryId!] || card.title;
      const dotColor =
        count === 0 ? 'bg-gray-500' : isLive ? 'bg-red-500' : 'bg-[#9c4af5]';

      return {
        ...card,
        isLive,
        count,
        displayName,
        dotColor,
      };
    });

    let result = cards;

    // Filter by search query
    if (categorySearch.trim()) {
      const q = categorySearch.toLowerCase().trim();
      result = result.filter(
        (c) =>
          c.displayName.toLowerCase().includes(q) ||
          (c.categoryId && c.categoryId.toLowerCase().includes(q))
      );
    }

    // Sort alphabetically (A-Z) if enabled
    if (sortAlphabetical) {
      result = [...result].sort((a, b) => a.displayName.localeCompare(b.displayName));
    }

    return result;
  }, [filteredChannels, categoryChannelCounts, categoryNames, categorySearch, sortAlphabetical]);

  const cardBg =
    theme === 'amoled'
      ? 'bg-[#121212] hover:bg-[#1a1a1a] border-white/5'
      : 'bg-[#262433] hover:bg-[#2d2b3d] border-white/5';

  return (
    <div className="w-full px-3 py-2 pb-12 overflow-y-auto">
      {/* Top Hero Navigation Banners: Browse by Country, Browse by Category, Favorites - 3 buttons in one line */}
      <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-4">
        {/* Browse by Country */}
        <div
          onClick={goToCountryBrowse}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') goToCountryBrowse();
          }}
          className={`group flex flex-col sm:flex-row items-center justify-center sm:justify-between p-2.5 sm:p-5 rounded-2xl sm:rounded-[24px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] hover:shadow-xl hover:shadow-red-500/10 relative overflow-hidden`}
        >
          <div className="flex flex-col sm:flex-row items-center gap-1.5 sm:gap-3.5 z-10 min-w-0 text-center sm:text-left">
            <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-red-600/15 border border-red-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Globe className="w-4 h-4 sm:w-6 sm:h-6 text-red-500" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 sm:gap-2">
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-[7px] bg-red-600 text-white font-extrabold text-[11px] uppercase tracking-wider">
                  Live
                </span>
                <h3 className="text-white text-xs sm:text-base font-bold truncate">
                  <span className="sm:hidden">Countries</span>
                  <span className="hidden sm:inline">Browse by Country</span>
                </h3>
              </div>
              <p className="hidden md:block text-xs text-white/50 mt-0.5 truncate">
                Explore channels by flags & regions
              </p>
            </div>
          </div>
          <ChevronRight className="hidden sm:block w-5 h-5 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all shrink-0 ml-2" />
        </div>

        {/* Browse by Category */}
        <div
          onClick={goToCategoryBrowse}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') goToCategoryBrowse();
          }}
          className={`group flex flex-col sm:flex-row items-center justify-center sm:justify-between p-2.5 sm:p-5 rounded-2xl sm:rounded-[24px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] hover:shadow-xl hover:shadow-[#9c4af5]/15 relative overflow-hidden`}
        >
          <div className="flex flex-col sm:flex-row items-center gap-1.5 sm:gap-3.5 z-10 min-w-0 text-center sm:text-left">
            <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-[#9c4af5]/15 border border-purple-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Layers className="w-4 h-4 sm:w-6 sm:h-6 text-[#9c4af5]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 sm:gap-2">
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-[7px] bg-[#9c4af5] text-white font-extrabold text-[11px] uppercase tracking-wider">
                  Genres
                </span>
                <h3 className="text-white text-xs sm:text-base font-bold truncate">
                  <span className="sm:hidden">Categories</span>
                  <span className="hidden sm:inline">Browse by Category</span>
                </h3>
              </div>
              <p className="hidden md:block text-xs text-white/50 mt-0.5 truncate">
                Explore TV genres with icons
              </p>
            </div>
          </div>
          <ChevronRight className="hidden sm:block w-5 h-5 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all shrink-0 ml-2" />
        </div>

        {/* Favorites Entry Card */}
        <div
          onClick={goToSavedChannels}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') goToSavedChannels();
          }}
          className={`group flex flex-col sm:flex-row items-center justify-center sm:justify-between p-2.5 sm:p-5 rounded-2xl sm:rounded-[24px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] hover:shadow-xl hover:shadow-rose-500/15 relative overflow-hidden`}
        >
          <div className="flex flex-col sm:flex-row items-center gap-1.5 sm:gap-3.5 z-10 min-w-0 text-center sm:text-left">
            <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-rose-500/15 border border-rose-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Heart className="w-4 h-4 sm:w-6 sm:h-6 text-rose-500 fill-rose-500/30 group-hover:fill-rose-500 transition-colors" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 sm:gap-2">
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-[7px] bg-rose-600 text-white font-extrabold text-[11px] uppercase tracking-wider">
                  Heart
                </span>
                <h3 className="text-white text-xs sm:text-base font-bold truncate">
                  Favorites
                </h3>
                {favorites.length > 0 && (
                  <span className="sm:hidden px-1.5 py-0.2 rounded-full bg-rose-500/25 text-rose-300 text-[10px] font-mono font-bold">
                    {favorites.length}
                  </span>
                )}
              </div>
              <p className="hidden md:block text-xs text-white/50 mt-0.5 truncate">
                {favorites.length} {favorites.length === 1 ? 'channel' : 'channels'} saved
              </p>
            </div>
          </div>
          <ChevronRight className="hidden sm:block w-5 h-5 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all shrink-0 ml-2" />
        </div>
      </div>

      {/* Favorites Quick Access Shelf (displayed if user has favorited channels) */}
      {favoriteChannelsList.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3 px-1">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-500">
                <Heart className="w-3.5 h-3.5 fill-rose-500" />
              </div>
              <h4 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
                Favorites
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[11px] font-semibold border border-rose-500/20">
                  {favoriteChannelsList.length}
                </span>
              </h4>
            </div>

            <button
              onClick={goToSavedChannels}
              className="text-xs font-semibold text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1"
            >
              <span>View all ({favoriteChannelsList.length})</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
            {favoriteChannelsList.slice(0, 5).map((channel) => (
              <div key={channel.id} className="relative group">
                <TvCard channel={channel} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recently Viewed Section (Tracks and displays last 5 opened channels) */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-[#9c4af5]/20 flex items-center justify-center text-[#9c4af5]">
              <History className="w-3.5 h-3.5" />
            </div>
            <h4 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
              Recently Viewed
              {recentlyViewed.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-[#c084fc] text-[11px] font-semibold border border-purple-500/20">
                  {recentlyViewed.length} / 5
                </span>
              )}
            </h4>
          </div>

          {recentlyViewed.length > 0 && (
            <button
              onClick={clearRecentlyViewed}
              className="text-xs text-white/40 hover:text-red-400 flex items-center gap-1.5 transition-colors px-2 py-1 rounded-xl hover:bg-white/5 active:scale-95"
              title="Clear recent channels"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear History</span>
            </button>
          )}
        </div>

        {recentlyViewed.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
            {recentlyViewed.map((channel) => (
              <div key={channel.id} className="relative group">
                <TvCard channel={channel} />
              </div>
            ))}
          </div>
        ) : (
          <div
            className={`p-4 sm:p-5 rounded-[22px] ${cardBg} border border-dashed border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3`}
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 shrink-0">
                <History className="w-5 h-5" />
              </div>
              <div>
                <p className="text-white text-sm font-semibold">No recent streams yet</p>
                <p className="text-xs text-white/50 mt-0.5">
                  Open any live channel to quickly jump back to your last 5 streams here.
                </p>
              </div>
            </div>
            <button
              onClick={goToCountryBrowse}
              className="px-3.5 py-1.5 rounded-xl bg-[#9c4af5]/20 hover:bg-[#9c4af5] text-purple-200 hover:text-white text-xs font-semibold transition-all active:scale-95 self-end sm:self-auto shadow-sm"
            >
              Browse live TV →
            </button>
          </div>
        )}
      </div>

      {/* Category Section Header with Alphabetical Sort & Real-time Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3 px-1">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <h4 className="text-sm sm:text-base font-bold text-white tracking-tight">
            TV Genres & Categories
          </h4>
          <span className="text-xs text-white/40">
            ({processedCategoryCards.length})
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Category Search input */}
          <div className="relative">
            <input
              type="text"
              value={categorySearch}
              onChange={(e) => setCategorySearch(e.target.value)}
              placeholder="Search categories..."
              className="w-36 sm:w-48 px-3 py-1.5 pl-8 pr-7 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5] transition-all"
            />
            <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
            {categorySearch && (
              <button
                onClick={() => setCategorySearch('')}
                className="absolute right-2 top-2 p-0.5 text-white/40 hover:text-white"
                title="Clear category search"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Alphabetical Sort Toggle */}
          <button
            onClick={() => setSortAlphabetical((prev) => !prev)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all active:scale-95 border ${
              sortAlphabetical
                ? 'bg-[#9c4af5] text-white border-purple-400/50 shadow-md shadow-[#9c4af5]/25 font-semibold'
                : 'bg-white/10 hover:bg-white/15 text-white/80 border-white/5'
            }`}
            title="Sort categories alphabetically A-Z"
          >
            <ArrowDownAZ className="w-3.5 h-3.5" />
            <span>A-Z</span>
          </button>

          <button
            onClick={goToCategoryBrowse}
            className="text-xs font-semibold text-[#9c4af5] hover:text-purple-300 transition-colors ml-1 hidden md:inline"
          >
            View all →
          </button>
        </div>
      </div>

      {/* Grid of Category Cards */}
      {processedCategoryCards.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-36 text-white/50 text-sm">
          <p>No categories matching &ldquo;{categorySearch}&rdquo;</p>
          <button
            onClick={() => setCategorySearch('')}
            className="mt-2 text-xs text-purple-400 hover:underline"
          >
            Clear search
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {processedCategoryCards.map((card, idx) => (
            <div
              key={idx}
              onClick={() => {
                if (card.isLive) {
                  goToCountryBrowse();
                } else {
                  goToCategoryChannels(card.categoryId!, card.displayName);
                }
              }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  if (card.isLive) {
                    goToCountryBrowse();
                  } else {
                    goToCategoryChannels(card.categoryId!, card.displayName);
                  }
                }
              }}
              className={`group flex flex-col justify-between p-4 sm:p-5 rounded-[24px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] hover:shadow-xl hover:shadow-[#9c4af5]/10 min-h-[140px] sm:min-h-[160px]`}
            >
              {/* Icon */}
              <div className="w-10 h-10 flex items-center justify-center mb-3">
                <img
                  src={card.icon}
                  alt={card.displayName}
                  className="w-10 h-10 object-contain drop-shadow group-hover:scale-110 transition-transform"
                />
              </div>

              {/* Title */}
              <div className="my-1">
                {card.isLive ? (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="px-2 py-0.5 rounded-[9px] bg-red-600 text-white font-extrabold text-sm sm:text-base leading-none uppercase tracking-wide">
                      Live
                    </span>
                    <span className="text-white text-base sm:text-lg font-medium">Tv</span>
                  </div>
                ) : (
                  <h3 className="text-white text-base sm:text-lg font-semibold truncate group-hover:text-purple-300 transition-colors">
                    {card.displayName}
                  </h3>
                )}
              </div>

              {/* Channel count row */}
              <div className="flex items-center gap-2 mt-2">
                <span className={`w-2 h-2 rounded-full ${card.dotColor} shrink-0`} />
                <span className="text-xs sm:text-sm text-gray-400 font-medium truncate">
                  {card.count.toLocaleString()} Channels
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
