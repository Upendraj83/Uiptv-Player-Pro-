import React, { useState } from 'react';
import { Heart, Tv } from 'lucide-react';
import { Channel } from '../types';
import { useApp } from '../context/AppContext';

export const TvCard: React.FC<{ channel: Channel }> = ({ channel }) => {
  const { isFavorite, toggleFavorite, playChannel, theme } = useApp();
  const [imageError, setImageError] = useState(false);
  const favorited = isFavorite(channel.id);

  const bestQuality = channel.streams.length > 0 ? channel.streams[0].quality : null;

  const cardBg = theme === 'amoled' ? 'bg-[#121212] border-white/5' : 'bg-[#262433] border-white/5';

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(channel.id);
  };

  return (
    <div
      onClick={() => playChannel(channel)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          playChannel(channel);
        }
      }}
      className={`group relative rounded-[20px] ${cardBg} border p-2 flex flex-col items-center justify-between cursor-pointer transition-all duration-200 hover:scale-[1.03] hover:shadow-xl hover:shadow-[#9c4af5]/10 select-none overflow-hidden aspect-square`}
    >
      {/* Artwork container */}
      <div className="relative w-full h-[72%] rounded-[16px] bg-black/40 flex items-center justify-center overflow-hidden">
        {channel.logo && !imageError ? (
          <img
            src={channel.logo}
            alt={channel.name}
            onError={() => setImageError(true)}
            loading="lazy"
            className="w-full h-full object-contain p-2 filter drop-shadow transition-transform duration-200 group-hover:scale-105"
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-white/30 gap-1.5 p-2">
            <Tv className="w-8 h-8 text-[#9c4af5]/60" />
            <span className="text-[10px] text-center font-medium line-clamp-1 max-w-[80%] text-white/50">
              {channel.name}
            </span>
          </div>
        )}

        {/* Favorite Heart Button (top-left) */}
        <button
          onClick={handleToggleFavorite}
          title={favorited ? 'Remove from Favorites' : 'Add to Favorites'}
          aria-label={favorited ? 'Remove from Favorites' : 'Add to Favorites'}
          className="absolute top-1.5 left-1.5 p-1 rounded-full bg-black/60 backdrop-blur-sm hover:bg-black/80 hover:scale-110 active:scale-90 transition-all z-10 group/heart"
        >
          <Heart
            className={`w-3.5 h-3.5 transition-all duration-200 ${
              favorited
                ? 'text-rose-500 fill-rose-500 drop-shadow'
                : 'text-white/70 group-hover/heart:text-rose-400'
            }`}
          />
        </button>

        {/* Quality Badge (top-right) */}
        {bestQuality && (
          <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/60 backdrop-blur-sm text-[9px] font-bold text-white/80 uppercase tracking-wider">
            {bestQuality}
          </div>
        )}

        {/* NSFW Badge */}
        {channel.isNsfw && (
          <div className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-red-600/80 backdrop-blur-sm text-[9px] font-bold text-white uppercase">
            18+
          </div>
        )}
      </div>

      {/* Channel Name */}
      <div className="w-full text-center px-1 py-1">
        <p className="text-white text-xs font-medium truncate group-hover:text-purple-300 transition-colors">
          {channel.name}
        </p>
      </div>
    </div>
  );
};
