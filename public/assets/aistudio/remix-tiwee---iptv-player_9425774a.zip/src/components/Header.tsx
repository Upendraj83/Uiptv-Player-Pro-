import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ArrowLeft, Settings, Search, X, Play, Heart, Tv, Sparkles, Cloud, Smartphone, Download } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Channel } from '../types';

function getChannelDescription(channel: Channel): string {
  if (channel.description && channel.description.trim()) {
    return channel.description;
  }
  const parts: string[] = [];
  if (channel.categories && channel.categories.length > 0) {
    parts.push(channel.categories.map((c) => c.charAt(0).toUpperCase() + c.slice(1)).join(', '));
  }
  if (channel.country) {
    parts.push(`Live from ${channel.country}`);
  }
  return parts.length > 0 ? parts.join(' • ') : 'Live stream';
}

const HighlightText: React.FC<{ text: string; query: string; className?: string }> = ({
  text,
  query,
  className = '',
}) => {
  if (!query.trim() || !text) {
    return <span className={className}>{text}</span>;
  }

  const cleanQ = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${cleanQ})`, 'gi');
  const parts = text.split(regex);

  return (
    <span className={className}>
      {parts.map((part, i) =>
        regex.test(part) ? (
          <mark key={i} className="bg-[#9c4af5]/40 text-purple-200 font-semibold px-0.5 rounded">
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </span>
  );
};

const ChannelSearchRow: React.FC<{
  channel: Channel;
  query: string;
  isSelected: boolean;
  onSelect: () => void;
}> = ({ channel, query, isSelected, onSelect }) => {
  const { playChannel, isFavorite, toggleFavorite } = useApp();
  const [imgError, setImgError] = useState(false);
  const favorited = isFavorite(channel.id);
  const desc = getChannelDescription(channel);
  const bestQuality = channel.streams.length > 0 ? channel.streams[0].quality : null;

  return (
    <div
      onClick={() => {
        playChannel(channel);
        onSelect();
      }}
      className={`group px-3 py-2.5 flex items-center justify-between gap-3 cursor-pointer transition-colors ${
        isSelected ? 'bg-[#9c4af5]/25 text-white' : 'hover:bg-white/5 text-white/90'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0 flex-1">
        {/* Logo / Thumbnail */}
        <div className="w-10 h-10 rounded-xl bg-black/40 border border-white/5 flex items-center justify-center overflow-hidden shrink-0 group-hover:border-purple-500/30 transition-colors">
          {channel.logo && !imgError ? (
            <img
              src={channel.logo}
              alt={channel.name}
              onError={() => setImgError(true)}
              loading="lazy"
              className="w-full h-full object-contain p-1"
            />
          ) : (
            <Tv className="w-5 h-5 text-[#9c4af5]/70" />
          )}
        </div>

        {/* Channel Details */}
        <div className="flex flex-col min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-semibold text-white truncate">
              <HighlightText text={channel.name} query={query} />
            </h4>

            {bestQuality && (
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-white/10 text-white/80 uppercase shrink-0">
                {bestQuality}
              </span>
            )}

            {channel.country && (
              <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-purple-500/20 text-purple-300 uppercase shrink-0">
                {channel.country}
              </span>
            )}
          </div>

          <p className="text-xs text-white/50 truncate mt-0.5 font-normal">
            <HighlightText text={desc} query={query} />
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(channel.id);
          }}
          title={favorited ? 'Remove from Favorites' : 'Add to Favorites'}
          className="p-1.5 rounded-lg hover:bg-white/10 active:scale-95 transition-all text-white/60 hover:text-white"
        >
          <Heart
            className={`w-4 h-4 ${
              favorited ? 'text-rose-500 fill-rose-500' : 'text-white/40 hover:text-rose-400'
            }`}
          />
        </button>

        <div className="w-7 h-7 rounded-lg bg-[#9c4af5]/20 group-hover:bg-[#9c4af5] flex items-center justify-center text-purple-300 group-hover:text-white transition-all shadow-sm">
          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
        </div>
      </div>
    </div>
  );
};

export const Header: React.FC<{ title?: string }> = ({ title }) => {
  const {
    currentView,
    canGoBack,
    goBack,
    goToSettings,
    searchQuery,
    setSearchQuery,
    goToAllChannels,
    filteredChannels,
    currentUser,
    loginWithGoogle,
    setIsAndroidApkModalOpen,
  } = useApp();

  const [time, setTime] = useState<string>('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Global Keyboard shortcut: Cmd+K / Ctrl+K or '/' to focus search
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInput =
        target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);

      if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !isInput)) {
        e.preventDefault();
        inputRef.current?.focus();
        inputRef.current?.select();
        setIsDropdownOpen(true);
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Real-time matches
  const { previewResults, totalMatchesCount } = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) {
      return { previewResults: [], totalMatchesCount: 0 };
    }

    const matches: Channel[] = [];
    let count = 0;

    for (const channel of filteredChannels) {
      const nameMatch = channel.name.toLowerCase().includes(q);
      const descMatch = Boolean(
        channel.description && channel.description.toLowerCase().includes(q)
      );
      const computedDescMatch =
        !channel.description && getChannelDescription(channel).toLowerCase().includes(q);
      const altMatch = channel.altNames.some((alt) => alt.toLowerCase().includes(q));
      const catMatch = channel.categories.some((cat) => cat.toLowerCase().includes(q));
      const countryMatch = channel.country.toLowerCase().includes(q);

      if (nameMatch || descMatch || computedDescMatch || altMatch || catMatch || countryMatch) {
        count++;
        if (matches.length < 12) {
          matches.push(channel);
        }
      }
    }

    return { previewResults: matches, totalMatchesCount: count };
  }, [filteredChannels, searchQuery]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isDropdownOpen && previewResults.length > 0) {
      setIsDropdownOpen(true);
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < previewResults.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : previewResults.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && previewResults[selectedIndex]) {
        // Play the highlighted channel
        const chosen = previewResults[selectedIndex];
        useApp().playChannel(chosen);
        setIsDropdownOpen(false);
      } else {
        // Navigate to full channel grid with search applied
        if (currentView !== 'all_channels') {
          goToAllChannels();
        }
        setIsDropdownOpen(false);
      }
    } else if (e.key === 'Escape') {
      setIsDropdownOpen(false);
      inputRef.current?.blur();
    }
  };

  const handleClear = () => {
    setSearchQuery('');
    setSelectedIndex(-1);
    inputRef.current?.focus();
  };

  const quickFilterSuggestions = ['News', 'Sports', 'Movies', 'Music', 'Kids', 'Documentary'];

  return (
    <header className="relative flex items-center justify-between py-3 px-3 sm:px-6 w-full gap-2 sm:gap-4 z-40">
      {/* Left side: Back / Logo Branding */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {canGoBack ? (
          <button
            onClick={goBack}
            className="p-2 sm:p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 transition-all text-white/80 hover:text-white"
            title="Go back"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : (
          <div className="flex items-center gap-2.5">
            <img
              src="/icons/Tiwee.png"
              alt="Tiwee"
              className="w-8 h-8 rounded-xl shadow-md shadow-[#9c4af5]/20"
            />
            <span className="font-bold text-xl tracking-tight text-white hidden md:inline">
              Tiwee
            </span>
          </div>
        )}

        {title && (
          <h1 className="text-base sm:text-lg font-semibold text-white/90 truncate max-w-[120px] sm:max-w-[200px] md:max-w-xs hidden sm:block">
            {title}
          </h1>
        )}
      </div>

      {/* Center: Global Search Bar */}
      <div ref={searchContainerRef} className="relative flex-1 max-w-2xl mx-1 sm:mx-2 min-w-0">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 pointer-events-none transition-colors group-focus-within:text-[#9c4af5]" />

          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsDropdownOpen(true);
              setSelectedIndex(-1);
            }}
            onFocus={() => {
              if (searchQuery.trim().length > 0) {
                setIsDropdownOpen(true);
              }
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search channels by name or description..."
            className="w-full py-2 pl-10 pr-20 sm:pr-24 rounded-2xl bg-white/10 hover:bg-white/[0.13] focus:bg-[#1a1727] text-white placeholder-white/40 text-xs sm:text-sm border border-white/10 focus:border-[#9c4af5]/70 focus:outline-none focus:ring-2 focus:ring-[#9c4af5]/30 transition-all shadow-sm"
          />

          {/* Right controls: Clear button + Shortcut hint */}
          <div className="absolute right-2.5 flex items-center gap-1.5">
            {searchQuery ? (
              <button
                type="button"
                onClick={handleClear}
                className="p-1 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors"
                title="Clear search"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono font-medium text-white/40 bg-white/5 border border-white/10 rounded-md">
                <span className="text-[11px]">⌘</span>K
              </kbd>
            )}
          </div>
        </div>

        {/* Real-time Search Dropdown Menu */}
        {isDropdownOpen && searchQuery.trim().length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-[#1b172a]/95 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
            {/* Header / Stats */}
            <div className="px-4 py-2.5 bg-white/5 border-b border-white/10 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white">
                  {totalMatchesCount.toLocaleString()} {totalMatchesCount === 1 ? 'channel' : 'channels'} found
                </span>
                <span className="text-white/40 hidden sm:inline">
                  (filtered by name & description)
                </span>
              </div>
              <span className="text-[11px] text-white/40 hidden md:inline">
                Use ↑↓ to navigate, Enter to play
              </span>
            </div>

            {/* Results List */}
            {previewResults.length > 0 ? (
              <>
                <div className="max-h-[360px] sm:max-h-[420px] overflow-y-auto divide-y divide-white/5">
                  {previewResults.map((channel, idx) => (
                    <ChannelSearchRow
                      key={channel.id}
                      channel={channel}
                      query={searchQuery}
                      isSelected={idx === selectedIndex}
                      onSelect={() => setIsDropdownOpen(false)}
                    />
                  ))}
                </div>

                {/* Footer: View all channels */}
                <div className="p-2.5 bg-black/30 border-t border-white/10 flex items-center justify-between gap-2">
                  <p className="text-[11px] text-white/50 pl-2 hidden sm:block">
                    Showing top {previewResults.length} of {totalMatchesCount} matches
                  </p>
                  <button
                    onClick={() => {
                      goToAllChannels();
                      setIsDropdownOpen(false);
                    }}
                    className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-xs font-semibold transition-all active:scale-95 shadow-md shadow-[#9c4af5]/25 flex items-center justify-center gap-1.5 ml-auto"
                  >
                    <span>View all in channel grid</span>
                    <span className="text-[10px] bg-white/20 px-1.5 py-0.2 rounded-full font-mono">
                      {totalMatchesCount}
                    </span>
                  </button>
                </div>
              </>
            ) : (
              /* Empty State */
              <div className="p-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-3 text-white/40">
                  <Search className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-semibold text-white mb-1">No channels found</h4>
                <p className="text-xs text-white/50 max-w-xs mx-auto mb-4">
                  No channels matched &ldquo;{searchQuery}&rdquo; by name or description.
                </p>

                {/* Quick suggestions */}
                <div className="flex flex-col items-center">
                  <span className="text-[11px] text-white/40 mb-2 flex items-center gap-1 font-medium">
                    <Sparkles className="w-3 h-3 text-purple-400" />
                    Try searching for popular categories:
                  </span>
                  <div className="flex flex-wrap justify-center gap-1.5">
                    {quickFilterSuggestions.map((tag) => (
                      <button
                        key={tag}
                        onClick={() => {
                          setSearchQuery(tag);
                          inputRef.current?.focus();
                        }}
                        className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white/80 hover:text-white text-xs transition-colors border border-white/5"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Right side: User Sync, Clock & Settings */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* User Account / Cloud Sync */}
        {currentUser ? (
          <button
            onClick={goToSettings}
            className="flex items-center gap-1.5 p-1 sm:px-2.5 sm:py-1 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 transition-all text-white border border-white/5"
            title={`Synced as ${currentUser.displayName || currentUser.email}`}
          >
            {currentUser.photoURL ? (
              <img
                src={currentUser.photoURL}
                alt=""
                className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg object-cover ring-1 ring-emerald-400"
              />
            ) : (
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-[#9c4af5] flex items-center justify-center text-[10px] font-bold">
                {currentUser.displayName ? currentUser.displayName[0].toUpperCase() : 'U'}
              </div>
            )}
            <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-emerald-400 shrink-0" />
          </button>
        ) : (
          <button
            onClick={() => loginWithGoogle().catch(() => {})}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#9c4af5]/20 hover:bg-[#9c4af5]/30 text-purple-200 text-xs font-semibold transition-all border border-[#9c4af5]/30 active:scale-95"
            title="Sign in with Google to sync favorites and history"
          >
            <Cloud className="w-3.5 h-3.5 text-purple-300" />
            <span>Sync</span>
          </button>
        )}

        {/* One-Touch Standalone APK Download Button */}
        <div className="flex items-center gap-1 bg-[#3DDC84]/15 rounded-xl border border-[#3DDC84]/30 p-0.5 shadow-sm shadow-[#3DDC84]/10">
          <a
            href="/Tiwee-IPTV-Android10-v2.1.apk"
            download="Tiwee-IPTV-Android10-v2.1.apk"
            className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1 rounded-lg bg-[#3DDC84] hover:bg-[#34c776] text-black text-xs font-bold transition-all active:scale-95 shadow-sm"
            title="One-Touch Download Standalone APK (Android 10+)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download APK</span>
            <span className="sm:hidden">APK</span>
          </a>
          <button
            onClick={() => setIsAndroidApkModalOpen(true)}
            className="p-1 rounded-lg text-[#3DDC84] hover:bg-[#3DDC84]/20 transition-colors"
            title="Android 10 Install Guide & QR Code"
            aria-label="Android APK Guide"
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Clock Label */}
        <div className="hidden sm:block px-3 py-1.5 rounded-xl bg-white/5 text-white/70 text-xs font-mono font-medium tracking-wider border border-white/5">
          {time}
        </div>

        {/* Settings button */}
        {currentView !== 'settings' && (
          <button
            onClick={goToSettings}
            className="p-2 sm:p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 transition-all text-white/80 hover:text-white border border-white/5"
            title="Settings"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        )}
      </div>
    </header>
  );
};
