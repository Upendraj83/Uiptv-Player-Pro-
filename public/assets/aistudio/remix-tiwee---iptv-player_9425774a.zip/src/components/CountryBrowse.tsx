import React, { useMemo, useState } from 'react';
import { Heart, Tv, Search, Layers } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Country, Channel } from '../types';

function flagFromCode(code: string): string {
  if (!code || code.length !== 2) return '🌐';
  const chars = [...code.toUpperCase()].map((c) => 127397 + c.charCodeAt(0));
  try {
    return String.fromCodePoint(...chars);
  } catch {
    return '🌐';
  }
}

interface CountryEntry {
  code: string;
  name: string;
  flag: string;
  channels: Channel[];
}

export const CountryBrowse: React.FC = () => {
  const {
    filteredChannels,
    countries,
    favorites,
    goToCountryChannels,
    goToCategoryBrowse,
    goToAllChannels,
    goToSavedChannels,
    theme,
  } = useApp();

  const [search, setSearch] = useState('');

  // Group channels by country
  const countryEntries: CountryEntry[] = useMemo(() => {
    const metaMap = new Map<string, Country>();
    for (const c of countries) {
      metaMap.set(c.code.toUpperCase(), c);
    }

    const grouped = new Map<string, Channel[]>();
    for (const ch of filteredChannels) {
      const code = (ch.country || 'OTHER').toUpperCase();
      if (!grouped.has(code)) {
        grouped.set(code, []);
      }
      grouped.get(code)!.push(ch);
    }

    const list: CountryEntry[] = [];
    for (const [code, channelsList] of grouped.entries()) {
      if (channelsList.length === 0) continue;
      const meta = metaMap.get(code);
      list.push({
        code,
        name: meta?.name || code,
        flag: meta?.flag || flagFromCode(code),
        channels: channelsList,
      });
    }

    // Sort most channels first
    list.sort((a, b) => b.channels.length - a.channels.length);
    return list;
  }, [filteredChannels, countries]);

  const filteredEntries = useMemo(() => {
    if (!search.trim()) return countryEntries;
    const q = search.toLowerCase();
    return countryEntries.filter(
      (c) => c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
    );
  }, [countryEntries, search]);

  const cardBg =
    theme === 'amoled'
      ? 'bg-[#121212] hover:bg-[#1a1a1a] border-white/5'
      : 'bg-[#262433] hover:bg-[#2d2b3d] border-white/5';

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-[9px] bg-red-600 text-white font-extrabold text-sm uppercase tracking-wide">
            Live
          </span>
          <span className="text-white text-xl font-bold">Tv by Country</span>
        </div>

        {/* Quick Search Countries */}
        <div className="relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search countries..."
            className="w-48 sm:w-64 px-3 py-1.5 pl-8 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5]"
          />
          <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Country Grid */}
      <div className="flex-1 overflow-y-auto min-h-0 pr-1 pb-4">
        {filteredEntries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            No countries found matching "{search}"
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {filteredEntries.map((country) => (
              <div
                key={country.code}
                onClick={() =>
                  goToCountryChannels({
                    code: country.code,
                    name: country.name,
                    flag: country.flag,
                  })
                }
                role="button"
                tabIndex={0}
                className={`p-4 rounded-[20px] ${cardBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] hover:shadow-lg hover:shadow-[#9c4af5]/10 flex flex-col justify-between min-h-[110px]`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-3xl filter drop-shadow">{country.flag}</span>
                  <span className="px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-mono text-white/70 uppercase">
                    {country.code}
                  </span>
                </div>

                <div className="mt-2">
                  <h4 className="text-white text-sm font-semibold truncate">{country.name}</h4>
                  <p className="text-xs text-gray-400 font-medium mt-0.5">
                    {country.channels.length.toLocaleString()} Channels
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Action Cards: Category, Fav & All */}
      <div className="pt-3 pb-4 grid grid-cols-3 gap-2.5 sm:gap-3 border-t border-white/5 shrink-0">
        <button
          onClick={goToCategoryBrowse}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBg} border hover:border-purple-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
              <Layers className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">By Category</p>
              <p className="text-[10px] text-gray-400 truncate">TV Genres</p>
            </div>
          </div>
        </button>

        <button
          onClick={goToSavedChannels}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBg} border hover:border-rose-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 shrink-0">
              <Heart className="w-4 h-4 fill-rose-500" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">Favorites</p>
              <p className="text-[10px] text-gray-400 truncate">{favorites.length} Saved</p>
            </div>
          </div>
        </button>

        <button
          onClick={goToAllChannels}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBg} border hover:border-blue-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
              <Tv className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">All Channels</p>
              <p className="text-[10px] text-gray-400 truncate">
                {filteredChannels.length.toLocaleString()} Total
              </p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
