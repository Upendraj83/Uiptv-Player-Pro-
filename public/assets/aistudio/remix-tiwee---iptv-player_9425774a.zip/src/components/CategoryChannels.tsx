import React, { useMemo, useState } from 'react';
import { Search, X, ArrowDownAZ } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TvCard } from './TvCard';
import { kCategoryType } from '../constants';

export const CategoryChannels: React.FC = () => {
  const { categoryChannels, selectedCategory } = useApp();
  const [search, setSearch] = useState('');
  const [sortAZ, setSortAZ] = useState(false);

  const displayedChannels = useMemo(() => {
    let list = categoryChannels;

    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.description && c.description.toLowerCase().includes(q)) ||
          c.country.toLowerCase().includes(q) ||
          c.altNames.some((alt) => alt.toLowerCase().includes(q))
      );
    }

    if (sortAZ) {
      list = [...list].sort((a, b) => a.name.localeCompare(b.name));
    }

    return list;
  }, [categoryChannels, search, sortAZ]);

  if (!selectedCategory) return null;

  const bannerImg =
    kCategoryType[selectedCategory.name] ||
    kCategoryType['Other'] ||
    'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&w=2070&q=80';

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Category Hero Banner */}
      <div className="relative w-full h-36 sm:h-44 rounded-[24px] overflow-hidden mb-4 shrink-0 shadow-lg border border-white/5">
        <img
          src={bannerImg}
          alt={selectedCategory.name}
          className="w-full h-full object-cover filter brightness-[0.45]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 flex flex-col justify-end p-5">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {selectedCategory.name}
          </h2>
          <p className="text-white/70 text-xs sm:text-sm mt-0.5">
            {categoryChannels.length.toLocaleString()} active channels
          </p>
        </div>
      </div>

      {/* Search and Alphabetical Sort Bar */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-white/80 text-sm font-semibold">Channels</span>
          <span className="text-xs text-white/40">
            ({displayedChannels.length})
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Alphabetical Sort Toggle */}
          <button
            onClick={() => setSortAZ((prev) => !prev)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all active:scale-95 border ${
              sortAZ
                ? 'bg-[#9c4af5] text-white border-purple-400/50 shadow-md shadow-[#9c4af5]/25 font-semibold'
                : 'bg-white/10 hover:bg-white/15 text-white/80 border-white/5'
            }`}
            title="Sort channels alphabetically A-Z"
          >
            <ArrowDownAZ className="w-3.5 h-3.5" />
            <span>A-Z</span>
          </button>

          {/* Search within category */}
          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search in ${selectedCategory.name}...`}
              className="w-48 sm:w-64 px-3 py-1.5 pl-8 pr-7 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5] transition-all"
            />
            <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-2 top-2 p-0.5 text-white/40 hover:text-white"
                title="Clear search"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto pb-8">
        {displayedChannels.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            <p>No channels found matching &ldquo;{search}&rdquo;</p>
            {search && (
              <button
                onClick={() => setSearch('')}
                className="mt-2 text-xs text-purple-400 hover:underline"
              >
                Clear search
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {displayedChannels.map((channel) => (
              <TvCard key={channel.id} channel={channel} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
