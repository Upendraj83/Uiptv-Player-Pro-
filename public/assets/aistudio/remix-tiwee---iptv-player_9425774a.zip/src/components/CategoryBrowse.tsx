import React, { useMemo, useState } from 'react';
import {
  Search,
  Sparkles,
  ArrowUpDown,
  ArrowDownAZ,
  ArrowUpZA,
  Tv,
  Heart,
  Globe2,
  X,
  Filter,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { kCategoryType } from '../constants';

// Mapping known category IDs / names to local SVG icons
const categoryIconMap: Record<string, string> = {
  news: '/icons/news.svg',
  sports: '/icons/sport.svg',
  sport: '/icons/sport.svg',
  music: '/icons/music.svg',
  movies: '/icons/popcorn.svg',
  movie: '/icons/popcorn.svg',
  series: '/icons/movie.svg',
  animation: '/icons/animation.svg',
  comedy: '/icons/comedy.svg',
  cooking: '/icons/cooking.svg',
  education: '/icons/education.svg',
  entertainment: '/icons/entertainment.svg',
  family: '/icons/family.svg',
  kids: '/icons/kids.svg',
  lifestyle: '/icons/life_style.svg',
  relax: '/icons/relaxation.svg',
  relaxation: '/icons/relaxation.svg',
  religious: '/icons/religious.svg',
  science: '/icons/science.svg',
  shop: '/icons/shop.svg',
  shopping: '/icons/shop.svg',
  auto: '/icons/auto.svg',
  automotive: '/icons/auto.svg',
  business: '/icons/business.svg',
  general: '/icons/tv.svg',
  classic: '/icons/movie.svg',
  documentary: '/icons/popcorn.svg',
  culture: '/icons/family.svg',
  outdoor: '/icons/sport.svg',
  travel: '/icons/life_style.svg',
  weather: '/icons/tv.svg',
  legislative: '/icons/business.svg',
};

// Genre accent color styles for visual richness
const genreAccents: Record<string, { bg: string; text: string; ring: string }> = {
  news: { bg: 'from-blue-600/20 to-blue-900/10', text: 'text-blue-400', ring: 'hover:border-blue-500/50' },
  sports: { bg: 'from-emerald-600/20 to-emerald-900/10', text: 'text-emerald-400', ring: 'hover:border-emerald-500/50' },
  sport: { bg: 'from-emerald-600/20 to-emerald-900/10', text: 'text-emerald-400', ring: 'hover:border-emerald-500/50' },
  movies: { bg: 'from-amber-600/20 to-amber-900/10', text: 'text-amber-400', ring: 'hover:border-amber-500/50' },
  movie: { bg: 'from-amber-600/20 to-amber-900/10', text: 'text-amber-400', ring: 'hover:border-amber-500/50' },
  music: { bg: 'from-pink-600/20 to-pink-900/10', text: 'text-pink-400', ring: 'hover:border-pink-500/50' },
  animation: { bg: 'from-orange-600/20 to-orange-900/10', text: 'text-orange-400', ring: 'hover:border-orange-500/50' },
  kids: { bg: 'from-yellow-600/20 to-yellow-900/10', text: 'text-yellow-400', ring: 'hover:border-yellow-500/50' },
  comedy: { bg: 'from-fuchsia-600/20 to-fuchsia-900/10', text: 'text-fuchsia-400', ring: 'hover:border-fuchsia-500/50' },
  science: { bg: 'from-cyan-600/20 to-cyan-900/10', text: 'text-cyan-400', ring: 'hover:border-cyan-500/50' },
  education: { bg: 'from-indigo-600/20 to-indigo-900/10', text: 'text-indigo-400', ring: 'hover:border-indigo-500/50' },
  documentary: { bg: 'from-teal-600/20 to-teal-900/10', text: 'text-teal-400', ring: 'hover:border-teal-500/50' },
  cooking: { bg: 'from-rose-600/20 to-rose-900/10', text: 'text-rose-400', ring: 'hover:border-rose-500/50' },
};

const defaultAccent = {
  bg: 'from-purple-600/20 to-purple-900/10',
  text: 'text-purple-400',
  ring: 'hover:border-purple-500/50',
};

interface GenreTileData {
  id: string;
  name: string;
  count: number;
  icon: string;
  bannerImage?: string;
  accent: { bg: string; text: string; ring: string };
}

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export const CategoryBrowse: React.FC = () => {
  const {
    filteredChannels,
    categories,
    goToCategoryChannels,
    goToCountryBrowse,
    goToAllChannels,
    goToSavedChannels,
    favorites,
    theme,
  } = useApp();

  const [search, setSearch] = useState('');
  // Default to alphabetical A-Z sorting
  const [sortBy, setSortBy] = useState<'alpha_asc' | 'alpha_desc' | 'count'>('alpha_asc');
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);

  // Dynamically compute all TV genres and their channel counts
  const rawGenreList: GenreTileData[] = useMemo(() => {
    // 1. Calculate active channel counts per category ID
    const countMap = new Map<string, number>();
    for (const channel of filteredChannels) {
      for (const cat of channel.categories) {
        const normalized = cat.toLowerCase();
        countMap.set(normalized, (countMap.get(normalized) || 0) + 1);
      }
    }

    // 2. Build a catalog map of category names
    const knownMap = new Map<string, string>();
    for (const c of categories) {
      knownMap.set(c.id.toLowerCase(), c.name);
    }

    // 3. Collect all unique categories from catalog + actual channels
    const allCategoryIds = new Set<string>();
    for (const c of categories) {
      allCategoryIds.add(c.id.toLowerCase());
    }
    for (const catId of countMap.keys()) {
      allCategoryIds.add(catId);
    }

    const list: GenreTileData[] = [];

    for (const catId of allCategoryIds) {
      const count = countMap.get(catId) || 0;
      if (count === 0) continue; // Only show genres that have active channels

      // Formulate display name
      const knownName = knownMap.get(catId);
      const displayName =
        knownName ||
        catId
          .split(/[-_]/)
          .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
          .join(' ');

      // Icon matching
      const icon = categoryIconMap[catId] || '/icons/tv.svg';

      // Artwork matching
      const bannerImage = kCategoryType[displayName] || kCategoryType[catId] || undefined;

      // Accent color matching
      const accent = genreAccents[catId] || defaultAccent;

      list.push({
        id: catId,
        name: displayName,
        count,
        icon,
        bannerImage,
        accent,
      });
    }

    return list;
  }, [filteredChannels, categories]);

  // Set of letters that have matching categories
  const activeLetters = useMemo(() => {
    const set = new Set<string>();
    for (const g of rawGenreList) {
      const firstChar = g.name.charAt(0).toUpperCase();
      if (firstChar >= 'A' && firstChar <= 'Z') {
        set.add(firstChar);
      }
    }
    return set;
  }, [rawGenreList]);

  // Filter and sort the genres
  const sortedAndFilteredGenres = useMemo(() => {
    let list = [...rawGenreList];

    // Filter by search query
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((g) => g.name.toLowerCase().includes(q) || g.id.toLowerCase().includes(q));
    }

    // Filter by alphabetical letter
    if (selectedLetter) {
      const letter = selectedLetter.toUpperCase();
      list = list.filter((g) => g.name.toUpperCase().startsWith(letter));
    }

    // Sort
    if (sortBy === 'alpha_asc') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === 'alpha_desc') {
      list.sort((a, b) => b.name.localeCompare(a.name));
    } else if (sortBy === 'count') {
      list.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    }

    return list;
  }, [rawGenreList, search, selectedLetter, sortBy]);

  const totalChannelsCount = useMemo(() => {
    return filteredChannels.length;
  }, [filteredChannels]);

  const cardBaseBg =
    theme === 'amoled'
      ? 'bg-[#121212] border-white/5'
      : 'bg-[#221f30] border-white/10';

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Top Header & Search / Sort Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-[9px] bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-extrabold text-xs uppercase tracking-wider shadow-sm">
              Explore
            </span>
            <h2 className="text-white text-xl sm:text-2xl font-bold tracking-tight">
              Browse by Category
            </h2>
          </div>
          <p className="text-xs text-white/50 mt-1">
            {sortedAndFilteredGenres.length} of {rawGenreList.length} categories across{' '}
            {totalChannelsCount.toLocaleString()} live channels
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Search genres input */}
          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                if (e.target.value && selectedLetter) {
                  setSelectedLetter(null); // Clear single letter filter when typing
                }
              }}
              placeholder="Search categories (e.g. Sports, News)..."
              className="w-56 sm:w-64 px-3 py-1.5 pl-8 pr-7 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5] transition-all"
            />
            <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-2 top-2 p-0.5 text-white/40 hover:text-white"
                title="Clear search"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Alphabetical / Popular Sort Buttons */}
          <div className="flex items-center rounded-xl bg-white/10 p-0.5 border border-white/5 text-xs">
            <button
              onClick={() => setSortBy(sortBy === 'alpha_asc' ? 'alpha_desc' : 'alpha_asc')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                sortBy === 'alpha_asc' || sortBy === 'alpha_desc'
                  ? 'bg-[#9c4af5] text-white font-semibold shadow-sm'
                  : 'text-white/70 hover:text-white'
              }`}
              title="Sort categories alphabetically"
            >
              {sortBy === 'alpha_desc' ? (
                <ArrowUpZA className="w-3.5 h-3.5" />
              ) : (
                <ArrowDownAZ className="w-3.5 h-3.5" />
              )}
              <span>{sortBy === 'alpha_desc' ? 'Z-A' : 'A-Z'}</span>
            </button>

            <button
              onClick={() => setSortBy('count')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                sortBy === 'count'
                  ? 'bg-[#9c4af5] text-white font-semibold shadow-sm'
                  : 'text-white/70 hover:text-white'
              }`}
              title="Sort by most channels"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Most Channels</span>
              <span className="sm:hidden">Count</span>
            </button>
          </div>
        </div>
      </div>

      {/* Alphabetical Quick Bar (A-Z jump pills) */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2.5 mb-2 scrollbar-none text-xs">
        <button
          onClick={() => setSelectedLetter(null)}
          className={`px-2.5 py-1 rounded-lg font-bold transition-all shrink-0 ${
            selectedLetter === null
              ? 'bg-[#9c4af5] text-white shadow-md shadow-[#9c4af5]/25'
              : 'bg-white/5 hover:bg-white/10 text-white/60 hover:text-white'
          }`}
        >
          ALL
        </button>

        {ALPHABET.map((letter) => {
          const hasCategories = activeLetters.has(letter);
          const isSelected = selectedLetter === letter;

          return (
            <button
              key={letter}
              disabled={!hasCategories}
              onClick={() => setSelectedLetter(isSelected ? null : letter)}
              className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs transition-all shrink-0 ${
                isSelected
                  ? 'bg-[#9c4af5] text-white shadow-md shadow-[#9c4af5]/30 scale-105'
                  : hasCategories
                  ? 'bg-white/5 hover:bg-white/10 text-white/80 hover:text-white'
                  : 'text-white/20 cursor-not-allowed opacity-40'
              }`}
            >
              {letter}
            </button>
          );
        })}
      </div>

      {/* Dynamic Category Tiles Grid */}
      <div className="flex-1 overflow-y-auto min-h-0 pr-1 pb-4">
        {sortedAndFilteredGenres.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            <Filter className="w-8 h-8 text-white/20 mb-2" />
            <p>
              No TV categories found
              {selectedLetter ? ` starting with "${selectedLetter}"` : ''}
              {search ? ` matching "${search}"` : ''}
            </p>
            <button
              onClick={() => {
                setSearch('');
                setSelectedLetter(null);
              }}
              className="mt-3 px-3 py-1.5 rounded-xl bg-white/10 text-xs text-purple-300 hover:text-white hover:bg-white/15 transition-colors"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {sortedAndFilteredGenres.map((genre) => (
              <div
                key={genre.id}
                onClick={() => goToCategoryChannels(genre.id, genre.name)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    goToCategoryChannels(genre.id, genre.name);
                  }
                }}
                className={`group relative flex flex-col justify-between p-4 sm:p-5 rounded-[22px] ${cardBaseBg} border cursor-pointer select-none transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] hover:shadow-xl hover:shadow-[#9c4af5]/15 ${genre.accent.ring} min-h-[145px] sm:min-h-[165px] overflow-hidden`}
              >
                {/* Subtle top gradient glow according to genre */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${genre.accent.bg} opacity-20 group-hover:opacity-40 transition-opacity pointer-events-none`}
                />

                {/* Top Row: Genre Icon & Indicator */}
                <div className="flex items-center justify-between z-10">
                  <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center p-2 group-hover:scale-110 group-hover:bg-[#9c4af5]/20 group-hover:border-purple-500/40 transition-all duration-200 shadow-sm">
                    <img
                      src={genre.icon}
                      alt={genre.name}
                      className="w-full h-full object-contain filter drop-shadow"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = '/icons/tv.svg';
                      }}
                    />
                  </div>

                  <span className="w-2 h-2 rounded-full bg-[#9c4af5] group-hover:scale-125 transition-transform shadow-sm shadow-[#9c4af5]/50" />
                </div>

                {/* Bottom Row: Genre Name and Channel Count */}
                <div className="mt-3 z-10">
                  <h3 className="text-white text-base sm:text-lg font-bold truncate group-hover:text-purple-300 transition-colors">
                    {genre.name}
                  </h3>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="text-xs sm:text-sm font-semibold text-white/80">
                      {genre.count.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-white/40 font-normal">Channels</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Quick Navigation Cards */}
      <div className="pt-3 pb-3 grid grid-cols-3 gap-2.5 sm:gap-3 border-t border-white/5 shrink-0">
        <button
          onClick={goToCountryBrowse}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBaseBg} border hover:border-purple-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0">
              <Globe2 className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">By Country</p>
              <p className="text-[10px] text-gray-400 truncate">World Channels</p>
            </div>
          </div>
        </button>

        <button
          onClick={goToSavedChannels}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBaseBg} border hover:border-rose-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 shrink-0">
              <Heart className="w-4 h-4 fill-rose-500" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">Favorites</p>
              <p className="text-[10px] text-gray-400 truncate">{favorites.length} Saved</p>
            </div>
          </div>
        </button>

        <button
          onClick={goToAllChannels}
          className={`flex items-center justify-between p-3 rounded-[18px] ${cardBaseBg} border hover:border-blue-400/40 transition-all active:scale-[0.98] text-left`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
              <Tv className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs sm:text-sm font-bold truncate">All Channels</p>
              <p className="text-[10px] text-gray-400 truncate">
                {totalChannelsCount.toLocaleString()} Total
              </p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
