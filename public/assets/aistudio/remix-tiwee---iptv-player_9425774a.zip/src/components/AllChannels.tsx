import React, { useMemo, useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TvCard } from './TvCard';

export const AllChannels: React.FC = () => {
  const { filteredChannels, categories, searchQuery, setSearchQuery } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [page, setPage] = useState<number>(1);
  const pageSize = 60;

  const sortedCategories = useMemo(() => {
    return [...categories].sort((a, b) => a.name.localeCompare(b.name));
  }, [categories]);

  const filtered = useMemo(() => {
    let list = filteredChannels;

    if (selectedCategory !== 'all') {
      const cat = selectedCategory.toLowerCase();
      list = list.filter((c) => c.categories.some((k) => k.toLowerCase() === cat));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.description && c.description.toLowerCase().includes(q)) ||
          c.country.toLowerCase().includes(q) ||
          c.altNames.some((alt) => alt.toLowerCase().includes(q)) ||
          c.categories.some((k) => k.toLowerCase().includes(q))
      );
    }

    return list;
  }, [filteredChannels, selectedCategory, searchQuery]);

  const visibleChannels = useMemo(() => {
    return filtered.slice(0, page * pageSize);
  }, [filtered, page, pageSize]);

  return (
    <div className="w-full flex flex-col h-full px-3 py-2">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-white text-xl font-bold">All Channels</h2>
          <p className="text-xs text-gray-400">
            {filtered.length.toLocaleString()} channels available
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Category Filter */}
          <div className="relative flex items-center">
            <Filter className="w-3.5 h-3.5 text-white/40 absolute left-2.5 pointer-events-none" />
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setPage(1);
              }}
              className="pl-8 pr-4 py-1.5 rounded-xl bg-white/10 text-white text-xs appearance-none focus:outline-none focus:ring-1 focus:ring-[#9c4af5] cursor-pointer"
            >
              <option value="all" className="bg-[#262433] text-white">
                All Categories
              </option>
              {sortedCategories.map((c) => (
                <option key={c.id} value={c.id} className="bg-[#262433] text-white">
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setPage(1);
              }}
              placeholder="Search all..."
              className="w-40 sm:w-56 px-3 py-1.5 pl-8 rounded-xl bg-white/10 text-white placeholder-white/40 text-xs focus:outline-none focus:ring-1 focus:ring-[#9c4af5]"
            />
            <Search className="w-3.5 h-3.5 text-white/40 absolute left-2.5 top-2.5" />
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto pb-8">
        {visibleChannels.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/50 text-sm">
            No channels found
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
              {visibleChannels.map((channel) => (
                <TvCard key={channel.id} channel={channel} />
              ))}
            </div>

            {visibleChannels.length < filtered.length && (
              <div className="flex justify-center mt-6">
                <button
                  onClick={() => setPage((p) => p + 1)}
                  className="px-6 py-2.5 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-xs font-semibold transition-all active:scale-95 shadow-lg shadow-[#9c4af5]/20"
                >
                  Load More ({filtered.length - visibleChannels.length} remaining)
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
