import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  QrCode,
  Check,
  Copy,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Layers,
  Terminal,
  Tv,
  ArrowDownCircle,
  FileDown,
  CheckCircle2,
  Info,
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidApkModalProps {
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'standalone' | 'webapk' | 'qr'>('standalone');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedSha, setCopiedSha] = useState(false);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [installing, setInstalling] = useState(false);
  const [qrType, setQrType] = useState<'apk' | 'web'>('apk');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // The permanent live URL for this app
  const appLiveUrl = window.location.origin.includes('run.app')
    ? window.location.origin.replace('ais-dev-', 'ais-pre-')
    : window.location.origin;

  const apkDownloadUrl = `${appLiveUrl}/Tiwee-IPTV-Android10-v2.1.apk`;
  const apkFileName = 'Tiwee-IPTV-Android10-v2.1.apk';
  const sha256Hash = '6dea608a5676d823aad7b6e9f169662b8a7c5eb376466de317195576b772774c';

  useEffect(() => {
    const targetUrl = qrType === 'apk' ? apkDownloadUrl : appLiveUrl;
    QRCode.toDataURL(targetUrl, {
      margin: 1,
      width: 240,
      color: {
        dark: '#12111a',
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.warn('QR Code generation error:', err));
  }, [qrType, apkDownloadUrl, appLiveUrl]);

  const handleDownloadClick = () => {
    setDownloadStarted(true);
    setTimeout(() => setDownloadStarted(false), 5000);
  };

  const handleInstallClick = async () => {
    setInstalling(true);
    try {
      await install();
    } finally {
      setInstalling(false);
    }
  };

  const copyToClipboard = (text: string, type: 'url' | 'sha') => {
    navigator.clipboard.writeText(text).then(() => {
      if (type === 'url') {
        setCopiedUrl(true);
        setTimeout(() => setCopiedUrl(false), 2500);
      } else {
        setCopiedSha(true);
        setTimeout(() => setCopiedSha(false), 2500);
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#161421] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-[#1d1933] via-[#1a172c] to-[#141222] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#3DDC84]/20 border border-[#3DDC84]/35 flex items-center justify-center text-[#3DDC84] shadow-lg shadow-[#3DDC84]/15 shrink-0">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-bold text-base sm:text-xl">
                  Android 10 Mobile APK
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#3DDC84]/20 text-[#3DDC84] border border-[#3DDC84]/35">
                  v2.1.0 • Android 10+
                </span>
              </div>
              <p className="text-white/60 text-xs mt-0.5">
                One-touch direct APK download and mobile installation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-white/10 bg-black/25 p-1.5 gap-1.5 overflow-x-auto">
          <button
            onClick={() => setActiveTab('standalone')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'standalone'
                ? 'bg-[#3DDC84] text-black shadow-md shadow-[#3DDC84]/20 font-bold'
                : 'text-white/70 hover:text-white hover:bg-white/5'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>One-Touch APK Download</span>
          </button>
          <button
            onClick={() => setActiveTab('webapk')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'webapk'
                ? 'bg-[#9c4af5] text-white shadow-md shadow-[#9c4af5]/20'
                : 'text-white/70 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>WebAPK (Chrome/Samsung)</span>
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'qr'
                ? 'bg-[#9c4af5] text-white shadow-md shadow-[#9c4af5]/20'
                : 'text-white/70 hover:text-white hover:bg-white/5'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Scan to Phone</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {activeTab === 'standalone' && (
            <div className="space-y-4">
              {/* Primary One-Touch Download Banner */}
              <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-[#3DDC84]/20 via-[#1f2823] to-[#14181f] border-2 border-[#3DDC84]/40 shadow-xl shadow-[#3DDC84]/10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-[#3DDC84] text-black">
                        Direct Download
                      </span>
                      <span className="text-[#3DDC84] text-xs font-semibold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> Standalone Signed Package
                      </span>
                    </div>
                    <h4 className="text-white font-extrabold text-lg sm:text-xl">
                      Tiwee IPTV for Android 10
                    </h4>
                    <p className="text-white/75 text-xs max-w-md leading-relaxed">
                      Download the standalone `.apk` directly to your phone. Includes hardware-accelerated
                      H.264/HEVC/HLS decoding, full-screen playback, and AMOLED dark mode.
                    </p>
                  </div>

                  {/* ONE-TOUCH DOWNLOAD BUTTON */}
                  <div className="flex flex-col gap-2 shrink-0">
                    <a
                      href="/Tiwee-IPTV-Android10-v2.1.apk"
                      download={apkFileName}
                      onClick={handleDownloadClick}
                      className="px-6 py-4 rounded-2xl bg-[#3DDC84] hover:bg-[#34c776] active:scale-95 text-black font-extrabold text-sm sm:text-base flex items-center justify-center gap-3 transition-all shadow-xl shadow-[#3DDC84]/30 group"
                    >
                      <ArrowDownCircle className="w-5 h-5 group-hover:translate-y-0.5 transition-transform" />
                      <span>One-Touch Download APK</span>
                    </a>
                    <span className="text-[11px] text-center text-white/50">
                      File: {apkFileName} • ~50 KB
                    </span>
                  </div>
                </div>

                {downloadStarted && (
                  <div className="mt-4 p-3 rounded-xl bg-[#3DDC84]/20 border border-[#3DDC84]/40 text-[#3DDC84] flex items-center gap-2.5 text-xs font-bold animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Download started! Pull down your Android notification bar to install.</span>
                  </div>
                )}
              </div>

              {/* Step-by-Step Android 10 Installation Walkthrough */}
              <div className="space-y-2.5">
                <h5 className="text-white/90 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-[#3DDC84]" />
                  <span>How to Install on Android 10 (3 Quick Steps):</span>
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-[#3DDC84]/20 text-[#3DDC84] font-mono text-xs flex items-center justify-center font-bold">
                        1
                      </span>
                      <h6 className="text-white text-xs font-bold">Tap Download</h6>
                    </div>
                    <p className="text-white/50 text-[11px] leading-relaxed">
                      Tap the green &ldquo;One-Touch Download APK&rdquo; button. The file saves instantly to your Downloads.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-[#3DDC84]/20 text-[#3DDC84] font-mono text-xs flex items-center justify-center font-bold">
                        2
                      </span>
                      <h6 className="text-white text-xs font-bold">Open File</h6>
                    </div>
                    <p className="text-white/50 text-[11px] leading-relaxed">
                      Swipe down your notification bar or open the <strong>Files / Downloads</strong> app, then tap <strong>{apkFileName}</strong>.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-[#3DDC84]/20 text-[#3DDC84] font-mono text-xs flex items-center justify-center font-bold">
                        3
                      </span>
                      <h6 className="text-white text-xs font-bold">Allow & Install</h6>
                    </div>
                    <p className="text-white/50 text-[11px] leading-relaxed">
                      If prompted on Android 10, tap <strong>Settings</strong> &rarr; toggle on <strong>Allow from this source</strong>, then tap <strong>Install</strong>.
                    </p>
                  </div>
                </div>
              </div>

              {/* Package Specs & Integrity Card */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-white/90 text-xs font-bold flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-purple-400" />
                    Package Specifications
                  </span>
                  <a
                    href="/tiwee-iptv.apk"
                    download="tiwee-iptv.apk"
                    className="text-[11px] text-[#3DDC84] hover:underline flex items-center gap-1"
                  >
                    <FileDown className="w-3 h-3" />
                    <span>Alternative Direct Mirror</span>
                  </a>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-white/5">
                    <span className="text-white/40 block text-[10px]">Package ID</span>
                    <span className="text-white font-mono font-medium truncate block">com.tiwee.iptv</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5">
                    <span className="text-white/40 block text-[10px]">Target OS</span>
                    <span className="text-white font-medium">Android 10 (API 29)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5">
                    <span className="text-white/40 block text-[10px]">Min Android</span>
                    <span className="text-white font-medium">Android 5.0+ (API 21)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5">
                    <span className="text-white/40 block text-[10px]">Architecture</span>
                    <span className="text-white font-medium">Universal (ARM/x86)</span>
                  </div>
                </div>

                {/* SHA-256 Hash box */}
                <div className="p-2.5 rounded-xl bg-black/60 border border-white/5 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] text-white/40 block">SHA-256 Checksum</span>
                    <span className="text-[11px] font-mono text-purple-200 truncate block select-all">
                      {sha256Hash}
                    </span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(sha256Hash, 'sha')}
                    className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white text-[11px] font-medium transition-colors shrink-0"
                  >
                    {copiedSha ? (
                      <span className="text-[#3DDC84] flex items-center gap-1">
                        <Check className="w-3 h-3" /> Copied
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <Copy className="w-3 h-3" /> Copy Hash
                      </span>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'webapk' && (
            <div className="space-y-4">
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#9c4af5]/15 via-white/5 to-transparent border border-[#9c4af5]/25">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h4 className="text-white font-bold text-base flex items-center gap-2">
                      <span>Native WebAPK System Install</span>
                      <ShieldCheck className="w-4 h-4 text-purple-400" />
                    </h4>
                    <p className="text-white/70 text-xs mt-1 max-w-md leading-relaxed">
                      Android 10 natively turns this application into an official WebAPK without any unknown-source
                      warnings. Tap below in Google Chrome, Edge, or Samsung Internet.
                    </p>
                  </div>

                  {isInstalled ? (
                    <div className="px-4 py-3 rounded-xl bg-[#3DDC84]/20 border border-[#3DDC84]/40 text-[#3DDC84] flex items-center gap-2 text-xs font-bold shrink-0">
                      <Check className="w-4 h-4" />
                      <span>Installed on Device</span>
                    </div>
                  ) : isInstallable ? (
                    <button
                      onClick={handleInstallClick}
                      disabled={installing}
                      className="px-5 py-3 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-xs font-bold flex items-center gap-2 transition-all shadow-lg shadow-[#9c4af5]/25 active:scale-95 shrink-0"
                    >
                      <Download className="w-4 h-4" />
                      <span>{installing ? 'Opening Prompt...' : 'Install WebAPK'}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setActiveTab('qr')}
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center gap-2 transition-all shrink-0"
                    >
                      <QrCode className="w-4 h-4 text-purple-400" />
                      <span>Open on Phone</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Android 10 WebAPK Features */}
              <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                <h5 className="text-white font-semibold text-xs mb-2.5 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Android 10 Native Capabilities</span>
                </h5>
                <div className="grid grid-cols-2 gap-2 text-xs text-white/70">
                  <div className="flex items-center gap-2">
                    <span className="text-[#3DDC84]">✓</span>
                    <span>System AMOLED Dark Mode</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[#3DDC84]">✓</span>
                    <span>Android 10 Edge-to-Edge display</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[#3DDC84]">✓</span>
                    <span>Hardware H.264/HLS video decode</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[#3DDC84]">✓</span>
                    <span>192px & 512px maskable adaptive icons</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'qr' && (
            <div className="flex flex-col items-center text-center space-y-4">
              {/* QR Mode Toggle */}
              <div className="flex p-1 rounded-xl bg-black/40 border border-white/10 text-xs">
                <button
                  onClick={() => setQrType('apk')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                    qrType === 'apk'
                      ? 'bg-[#3DDC84] text-black shadow-sm'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  Direct APK Download QR
                </button>
                <button
                  onClick={() => setQrType('web')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                    qrType === 'web'
                      ? 'bg-[#9c4af5] text-white shadow-sm'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  Mobile Web App QR
                </button>
              </div>

              <div className="p-3 bg-white rounded-2xl shadow-xl shadow-black/50">
                {qrDataUrl ? (
                  <img src={qrDataUrl} alt="QR Code" className="w-48 h-48 rounded-lg" />
                ) : (
                  <div className="w-48 h-48 flex items-center justify-center text-black/40 font-mono text-xs">
                    Generating QR...
                  </div>
                )}
              </div>

              <div className="max-w-md space-y-1.5">
                <h4 className="text-white font-bold text-sm">
                  {qrType === 'apk'
                    ? 'Scan to Download APK Directly'
                    : 'Scan to Open Tiwee IPTV on Android 10'}
                </h4>
                <p className="text-white/60 text-xs">
                  {qrType === 'apk'
                    ? 'Point your Android camera or Google Lens at this code to instantly download the APK file.'
                    : 'Point your camera at this code to open the full web app directly on your phone.'}
                </p>
              </div>

              {/* Shareable Link Box */}
              <div className="w-full max-w-md p-2 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-2">
                <span className="text-xs text-white/70 truncate font-mono px-2 select-all">
                  {qrType === 'apk' ? apkDownloadUrl : appLiveUrl}
                </span>
                <button
                  onClick={() => copyToClipboard(qrType === 'apk' ? apkDownloadUrl : appLiveUrl, 'url')}
                  className="px-3 py-1.5 rounded-lg bg-[#9c4af5] hover:bg-[#8630df] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-3 h-3 text-[#3DDC84]" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer with One-Touch Action */}
        <div className="p-4 bg-black/40 border-t border-white/10 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-white/50 truncate">
            <Tv className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="truncate">Tiwee IPTV • Android 10 Mobile Standalone APK</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <a
              href="/Tiwee-IPTV-Android10-v2.1.apk"
              download={apkFileName}
              onClick={handleDownloadClick}
              className="px-3.5 py-1.5 rounded-xl bg-[#3DDC84] hover:bg-[#34c776] text-black text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 shadow-md shadow-[#3DDC84]/20"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .apk</span>
            </a>
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
