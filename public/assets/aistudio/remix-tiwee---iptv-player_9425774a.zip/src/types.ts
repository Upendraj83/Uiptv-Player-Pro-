export interface Stream {
  url: string;
  title: string;
  quality?: string | null;
  userAgent?: string | null;
  referrer?: string | null;
}

export interface Channel {
  id: string;
  name: string;
  altNames: string[];
  country: string;
  categories: string[];
  isNsfw: boolean;
  logo?: string | null;
  streams: Stream[];
  description?: string | null;
}

export interface Category {
  id: string;
  name: string;
}

export interface Country {
  name: string;
  code: string;
  flag?: string;
  languages?: string[];
}

export interface ParentalSettings {
  allowAdultChannels: boolean;
  pin: string | null;
}

export type ThemePalette = 'dark' | 'amoled';

export interface SleepTimerState {
  minutes: number | null;
  targetTimestamp: number | null;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

