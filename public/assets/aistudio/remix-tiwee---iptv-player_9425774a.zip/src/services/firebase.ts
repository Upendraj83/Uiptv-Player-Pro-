import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  User,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  onSnapshot,
  serverTimestamp,
  getDocFromServer,
  Unsubscribe,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// Initialize Firestore with explicit Database ID as required by AI Studio
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Firebase Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Validates connection to Firestore server on application initialization
 */
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration: Client is offline.');
    }
    return false;
  }
}

export interface SyncedUserData {
  id: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  theme?: 'dark' | 'amoled';
  favorites?: string[];
  recentlyViewed?: string[];
  allowAdultChannels?: boolean;
}

/**
 * Fetch or initialize a user profile document in Firestore
 */
export async function getOrCreateUserProfile(
  user: User,
  initialData?: Partial<SyncedUserData>
): Promise<SyncedUserData | null> {
  const path = `users/${user.uid}`;
  const userDocRef = doc(db, path);

  try {
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      const data = snap.data();
      return {
        id: user.uid,
        email: data.email || user.email || '',
        displayName: data.displayName || user.displayName || '',
        photoURL: data.photoURL || user.photoURL || '',
        theme: data.theme || 'dark',
        favorites: Array.isArray(data.favorites) ? data.favorites : [],
        recentlyViewed: Array.isArray(data.recentlyViewed) ? data.recentlyViewed : [],
        allowAdultChannels: Boolean(data.allowAdultChannels),
      };
    }

    // Document does not exist, create it conforming to blueprint & security rules
    const newDoc = {
      id: user.uid,
      email: user.email || `${user.uid}@tiwee.app`,
      displayName: user.displayName || 'Tiwee Viewer',
      photoURL: user.photoURL || '',
      theme: initialData?.theme || 'dark',
      favorites: initialData?.favorites || [],
      recentlyViewed: initialData?.recentlyViewed || [],
      allowAdultChannels: Boolean(initialData?.allowAdultChannels),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(userDocRef, newDoc);
    return {
      id: user.uid,
      email: newDoc.email,
      displayName: newDoc.displayName,
      photoURL: newDoc.photoURL,
      theme: newDoc.theme,
      favorites: newDoc.favorites,
      recentlyViewed: newDoc.recentlyViewed,
      allowAdultChannels: newDoc.allowAdultChannels,
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Save user updates to Firestore
 */
export async function saveUserDataToFirestore(
  userId: string,
  data: Partial<Omit<SyncedUserData, 'id'>>
): Promise<void> {
  const path = `users/${userId}`;
  const userDocRef = doc(db, path);

  try {
    const updatePayload: Record<string, any> = {
      ...data,
      updatedAt: serverTimestamp(),
    };
    await updateDoc(userDocRef, updatePayload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

/**
 * Subscribe to realtime updates for user data in Firestore
 */
export function subscribeToUserProfile(
  userId: string,
  onData: (data: SyncedUserData) => void
): Unsubscribe {
  const path = `users/${userId}`;
  const userDocRef = doc(db, path);

  return onSnapshot(
    userDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        onData({
          id: userId,
          email: data.email || '',
          displayName: data.displayName || '',
          photoURL: data.photoURL || '',
          theme: data.theme || 'dark',
          favorites: Array.isArray(data.favorites) ? data.favorites : [],
          recentlyViewed: Array.isArray(data.recentlyViewed) ? data.recentlyViewed : [],
          allowAdultChannels: Boolean(data.allowAdultChannels),
        });
      }
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, path);
    }
  );
}

/**
 * Sign in with Google Popup
 * Returns the authenticated User, or null if cancelled or closed by user.
 */
export async function signInWithGoogle(): Promise<User | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    if (
      error?.code === 'auth/popup-closed-by-user' ||
      error?.code === 'auth/cancelled-popup-request' ||
      error?.message?.includes('popup-closed-by-user') ||
      error?.message?.includes('cancelled-popup-request')
    ) {
      // User closed the popup before completing sign in - this is expected user behavior
      return null;
    }
    throw error;
  }
}

/**
 * Sign out
 */
export async function signOutCurrentUser(): Promise<void> {
  await signOut(auth);
}
