import { Category, Channel, Country, Stream } from '../types';

const API_BASE = 'https://iptv-org.github.io/api';
const DB_NAME = 'tiwee_cache_db';
const DB_VERSION = 1;
const STORE_NAME = 'catalog_store';
const CACHE_KEY = 'assembled_catalog';
const CACHE_TTL_MS = 1000 * 60 * 60 * 6; // 6 hours

interface CachedPayload {
  timestamp: number;
  channels: Channel[];
  categories: Category[];
  countries: Country[];
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB not supported'));
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getCachedCatalog(): Promise<CachedPayload | null> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(CACHE_KEY);
      request.onsuccess = () => {
        const data = request.result as CachedPayload | undefined;
        if (data && Date.now() - data.timestamp < CACHE_TTL_MS) {
          resolve(data);
        } else {
          resolve(null);
        }
      };
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function setCachedCatalog(data: CachedPayload): Promise<void> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(data, CACHE_KEY);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('Failed to cache catalog in IndexedDB', err);
  }
}

function getQualityRank(quality?: string | null): number {
  if (!quality) return 1;
  const q = quality.toLowerCase();
  if (q.includes('4k') || q.includes('2160')) return 6;
  if (q.includes('1080') || q.includes('fhd')) return 5;
  if (q.includes('720') || q.includes('hd')) return 4;
  if (q.includes('576') || q.includes('480') || q.includes('sd')) return 3;
  if (q.includes('360') || q.includes('240')) return 2;
  return 1;
}

export interface CatalogData {
  channels: Channel[];
  categories: Category[];
  countries: Country[];
}

export async function fetchAndAssembleCatalog(
  forceRefresh = false,
  onProgress?: (msg: string) => void
): Promise<CatalogData> {
  if (!forceRefresh) {
    const cached = await getCachedCatalog();
    if (cached && cached.channels.length > 0) {
      return {
        channels: cached.channels,
        categories: cached.categories,
        countries: cached.countries,
      };
    }
  }

  onProgress?.('Fetching channels, categories & streams...');

  const [categoriesRes, countriesRes, streamsRes, logosRes, channelsRes] = await Promise.all([
    fetch(`${API_BASE}/categories.json`).then((r) => r.json()).catch(() => []),
    fetch(`${API_BASE}/countries.json`).then((r) => r.json()).catch(() => []),
    fetch(`${API_BASE}/streams.json`).then((r) => r.json()).catch(() => []),
    fetch(`${API_BASE}/logos.json`).then((r) => r.json()).catch(() => []),
    fetch(`${API_BASE}/channels.json`).then((r) => r.json()).catch(() => []),
  ]);

  onProgress?.('Assembling catalog streams & logos...');

  // Group streams by channel
  const streamsByChannel = new Map<string, Stream[]>();
  for (const item of streamsRes) {
    const channelId = item.channel;
    const url = item.url;
    if (!channelId || !url) continue;

    const stream: Stream = {
      url,
      title: item.title || '',
      quality: item.quality || null,
      userAgent: item.user_agent || null,
      referrer: item.http_referrer || null,
    };

    if (!streamsByChannel.has(channelId)) {
      streamsByChannel.set(channelId, []);
    }
    streamsByChannel.get(channelId)!.push(stream);
  }

  // Sort streams by quality rank descending
  for (const streams of streamsByChannel.values()) {
    if (streams.length > 1) {
      streams.sort((a, b) => getQualityRank(b.quality) - getQualityRank(a.quality));
    }
  }

  // Choose best logo by channel
  const logosByChannel = new Map<string, string>();
  const logoScores = new Map<string, number>();

  for (const logo of logosRes) {
    const channelId = logo.channel;
    const url = logo.url;
    if (!channelId || !url) continue;
    const inUse = logo.in_use !== false;
    const feed = logo.feed;
    const score = (inUse ? 2 : 0) + (!feed ? 1 : 0);
    const existingScore = logoScores.get(channelId) ?? -1;

    if (score > existingScore) {
      logoScores.set(channelId, score);
      logosByChannel.set(channelId, url);
    }
  }

  // Assemble channels
  const playableChannels: Channel[] = [];
  for (const raw of channelsRes) {
    const id = raw.id;
    if (!id || raw.closed || raw.replaced_by) continue;

    const streams = streamsByChannel.get(id);
    if (!streams || streams.length === 0) continue;

    const descParts: string[] = [];
    if (raw.description) {
      descParts.push(raw.description);
    } else {
      if (raw.network) descParts.push(`${raw.network} network`);
      if (Array.isArray(raw.categories) && raw.categories.length > 0) {
        descParts.push(raw.categories.map((c: string) => c.charAt(0).toUpperCase() + c.slice(1)).join(', '));
      }
      if (raw.country) {
        descParts.push(`Live from ${raw.country}`);
      }
      if (raw.broadcast_area) {
        descParts.push(`Broadcast: ${raw.broadcast_area}`);
      }
    }
    const computedDescription = descParts.length > 0 ? descParts.join(' • ') : (raw.website || null);

    playableChannels.push({
      id,
      name: raw.name || id,
      altNames: Array.isArray(raw.alt_names) ? raw.alt_names : [],
      country: raw.country || '',
      categories: Array.isArray(raw.categories) ? raw.categories : [],
      isNsfw: Boolean(raw.is_nsfw),
      logo: logosByChannel.get(id) || null,
      streams,
      description: computedDescription,
    });
  }

  const categories: Category[] = categoriesRes.map((c: any) => ({
    id: c.id,
    name: c.name,
  }));

  const countries: Country[] = countriesRes.map((c: any) => ({
    name: c.name,
    code: c.code,
    flag: c.flag,
    languages: c.languages,
  }));

  const result: CatalogData = {
    channels: playableChannels,
    categories,
    countries,
  };

  // Cache in IndexedDB
  await setCachedCatalog({
    timestamp: Date.now(),
    channels: playableChannels,
    categories,
    countries,
  });

  return result;
}
