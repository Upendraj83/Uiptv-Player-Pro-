// Protect window.fetch against re-assignment errors by browser extensions
try {
  let activeFetch = window.fetch;
  if (activeFetch) {
    Object.defineProperty(window, 'fetch', {
      get: () => activeFetch,
      set: (fn) => {
        activeFetch = fn;
      },
      configurable: true,
      enumerable: true,
    });
  }
} catch {
  // Ignore if already defined or restricted
}

import {createRoot} from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

// Register service worker for Android WebAPK & offline caching
registerSW({ immediate: true });

createRoot(document.getElementById('root')!).render(<App />);
