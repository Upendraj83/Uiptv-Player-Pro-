import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { MenuGrid } from './components/MenuGrid';
import { CountryBrowse } from './components/CountryBrowse';
import { CountryChannels } from './components/CountryChannels';
import { CategoryBrowse } from './components/CategoryBrowse';
import { CategoryChannels } from './components/CategoryChannels';
import { AllChannels } from './components/AllChannels';
import { SavedChannels } from './components/SavedChannels';
import { SettingsView } from './components/SettingsView';
import { PlayerModal } from './components/PlayerModal';
import { AndroidApkModal } from './components/AndroidApkModal';
import { RefreshCw, AlertCircle } from 'lucide-react';

const MainScreen: React.FC = () => {
  const {
    currentView,
    loading,
    progressMessage,
    error,
    refreshCatalog,
    theme,
    activeChannel,
    playChannel,
    isAndroidApkModalOpen,
    setIsAndroidApkModalOpen,
  } = useApp();

  const bgGradient =
    theme === 'amoled'
      ? 'from-[#000000] to-[#0a0a0a]'
      : 'from-[#1c1829] via-[#201d30] to-[#262436]';

  if (loading) {
    return (
      <div
        className={`w-full h-screen bg-gradient-to-br ${bgGradient} flex flex-col items-center justify-center p-6 text-center select-none`}
      >
        <div className="relative mb-6">
          <img
            src="/icons/Tiwee.png"
            alt="Tiwee"
            className="w-24 h-24 rounded-3xl shadow-2xl shadow-[#9c4af5]/30 animate-pulse"
          />
          <div className="absolute -inset-1 rounded-3xl bg-[#9c4af5]/20 blur-xl -z-10 animate-pulse" />
        </div>

        <h1 className="text-2xl font-bold text-white tracking-tight mb-2">Tiwee</h1>
        <p className="text-white/60 text-sm max-w-xs mb-6">{progressMessage}</p>

        <div className="w-48 h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div className="w-1/2 h-full bg-[#9c4af5] rounded-full animate-indeterminate" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className={`w-full h-screen bg-gradient-to-br ${bgGradient} flex flex-col items-center justify-center p-6 text-center select-none`}
      >
        <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center text-red-400 mb-4">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Could not load catalog</h2>
        <p className="text-white/60 text-sm max-w-md mb-6">{error}</p>
        <button
          onClick={() => refreshCatalog(true)}
          className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#9c4af5] hover:bg-[#8630df] text-white text-sm font-semibold transition-all active:scale-95 shadow-lg shadow-[#9c4af5]/25"
        >
          <RefreshCw className="w-4 h-4" />
          Retry Connection
        </button>
      </div>
    );
  }

  return (
    <div
      className={`w-full min-h-screen bg-gradient-to-br ${bgGradient} text-white flex flex-col font-sans select-none antialiased`}
    >
      <div className="max-w-7xl w-full mx-auto flex flex-col flex-1">
        <Header />

        <main className="flex-1 flex flex-col overflow-hidden">
          {currentView === 'menu' && <MenuGrid />}
          {currentView === 'country_browse' && <CountryBrowse />}
          {currentView === 'country_channels' && <CountryChannels />}
          {currentView === 'category_browse' && <CategoryBrowse />}
          {currentView === 'category_channels' && <CategoryChannels />}
          {currentView === 'all_channels' && <AllChannels />}
          {currentView === 'saved_channels' && <SavedChannels />}
          {currentView === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Video Player Modal */}
      {activeChannel && (
        <PlayerModal channel={activeChannel} onClose={() => playChannel(null)} />
      )}

      {/* Android 10 Mobile Version & APK Modal */}
      {isAndroidApkModalOpen && (
        <AndroidApkModal onClose={() => setIsAndroidApkModalOpen(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainScreen />
    </AppProvider>
  );
}
