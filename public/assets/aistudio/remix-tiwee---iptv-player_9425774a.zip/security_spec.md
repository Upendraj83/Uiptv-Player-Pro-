# Security Specification: Tiwee IPTV Player

## 1. Data Invariants

1. **Identity & Ownership Integrity**: A user document at `/users/{userId}` can only be accessed or modified if `request.auth.uid == userId`. Users cannot read, write, or enumerate other users' documents.
2. **Path Parameter Invariant**: Document ID `{userId}` must be a valid, sanitised ID (`isValidId`) matching `^[a-zA-Z0-9_\-]+$` and `<= 128` chars.
3. **No Unrestricted Queries**: Blanket listing of the `users` collection is forbidden (`allow list: if false`). Single document access is allowed only if authenticated user is the document owner.
4. **Immutable Identity & Creation**: The `id` field must strictly match `request.auth.uid`. The `createdAt` timestamp is immutable once created.
5. **Array Boundary Limits**: `favorites` must be an array with `.size() <= 200`. `recentlyViewed` must be an array with `.size() <= 30`.
6. **Payload Sanitization**: Allowed fields are strictly constrained on create and update to prevent phantom/ghost property injection.
7. **Strict Timestamps**: `createdAt` must equal `request.time` on create, and `updatedAt` must equal `request.time` on create and update.
8. **Catch-All Default Deny**: All unmapped paths are closed by default (`allow read, write: if false`).

---

## 2. The Dirty Dozen Payloads

1. **Payload 1: Unauthenticated Read** - Reading `/users/user_123` with `request.auth = null`. (Denied: Must be authenticated).
2. **Payload 2: Cross-User Read** - User `attacker_456` attempting to read `/users/victim_123`. (Denied: Ownership check).
3. **Payload 3: Cross-User Write** - User `attacker_456` attempting to write to `/users/victim_123`. (Denied: Ownership check).
4. **Payload 4: Identity Spoofing in Body** - User `user_123` sending body with `id: "admin_999"`. (Denied: Body `id` must match `request.auth.uid`).
5. **Payload 5: Collection Scraping / List Query** - User `user_123` issuing `getDocs(collection(db, 'users'))`. (Denied: No blanket list).
6. **Payload 6: Ghost Field Injection** - User sending `{ id: "user_123", email: "...", role: "admin", isSuperUser: true }`. (Denied: `hasOnly` schema validation).
7. **Payload 7: Unbounded Favorites Array Attack** - User sending `favorites` with 500 items. (Denied: Max array size <= 200).
8. **Payload 8: Unbounded Recently Viewed Array Attack** - User sending `recentlyViewed` with 100 items. (Denied: Max array size <= 30).
9. **Payload 9: Forged Timestamp Creation** - User providing `createdAt: timestamp_in_past`. (Denied: `request.time` server enforcement).
10. **Payload 10: Immutable Field Mutation** - User attempting to update `createdAt` to another timestamp. (Denied: `createdAt` is immutable).
11. **Payload 11: Malicious Document ID Traversal** - Attacker querying path `/users/../admin_secrets`. (Denied: Path validation `isValidId`).
12. **Payload 12: Invalid Theme Enum Poisoning** - User attempting to set `theme: "malicious_script_theme"`. (Denied: Enum must be 'dark' or 'amoled').
